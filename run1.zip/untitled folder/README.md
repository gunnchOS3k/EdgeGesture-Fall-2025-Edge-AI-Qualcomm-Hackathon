# EdgeGesture-Fall-2025-Edge-AI-Qualcomm-Hackathon
Edge-IO is a voice- and gesture-controlled mini-arcade for ARM PCs. We fuse on-device KWS/Whisper ASR via ONNX Runtime with hand-tracking to run 3 games—Pong, a Galaga-style shooter, and a karaoke/rhythm tease—entirely offline. Commands like “start”, “shoot”, “dump”, “cease”. Low-latency, privacy-preserving, EXE-packaged and well-documented.
