# EdgeGesture - Voice-Controlled Keyboard Automation

## 🎯 Project Overview

EdgeGesture is a voice-controlled keyboard automation system built for the Qualcomm Edge AI Hackathon. It uses real-time speech transcription with Whisper to detect voice commands and automatically trigger keyboard actions.

## 🚀 Features

- **Real-time Speech Transcription**: Uses OpenAI's Whisper model for accurate speech-to-text
- **Voice-Controlled Automation**: Detects "Start" and "Pause" commands to trigger keyboard actions
- **Cross-platform Compatibility**: Works on macOS, Linux, and Windows
- **Edge AI Ready**: Optimized for local processing without cloud dependencies
- **Configurable Triggers**: Customizable voice commands and keyboard mappings

## 🎮 Voice Commands

- **"Start"** (or "begin", "go", "play") → **Presses Enter key**
- **"Pause"** (or "stop", "halt", "wait") → **Presses Escape key**

## 🛠️ Setup Instructions

### Prerequisites
- Python 3.8+
- macOS (for keyboard automation)
- Microphone access

### Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/gunnchOS3k/EdgeGesture-Fall-2025-Edge-AI-Qualcomm-Hackathon.git
   cd EdgeGesture-Fall-2025-Edge-AI-Qualcomm-Hackathon
   ```

2. **Create virtual environment**:
   ```bash
   python3 -m venv whisper-venv
   source whisper-venv/bin/activate  # On Windows: whisper-venv\Scripts\activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements_simple.txt
   ```

4. **Grant Accessibility Permissions (macOS)**:
   - System Preferences → Security & Privacy → Privacy → Accessibility
   - Add Terminal to the list
   - Restart Terminal

### Usage

#### Basic Transcription (No Automation)
```bash
python simple_whisper_transcriber.py
```

#### Full Voice Automation
```bash
python whisper_with_macos_automation.py
```

## 📁 Project Structure

```
EdgeGesture-Fall-2025-Edge-AI-Qualcomm-Hackathon/
├── simple_whisper_transcriber.py          # Basic transcription tool
├── whisper_with_macos_automation.py       # Full automation with keyboard control
├── config.yaml                            # Configuration settings
├── requirements_simple.txt                # Python dependencies
├── SETUP_PERMISSIONS.md                   # Permission setup guide
├── USAGE.md                               # Detailed usage instructions
└── README_EDGEGESTURE.md                  # This file
```

## ⚙️ Configuration

Edit `config.yaml` to customize:

```yaml
# Audio settings
sample_rate: 16000
chunk_duration: 4
channels: 1

# Processing settings
max_workers: 2
silence_threshold: 0.001

# Automation settings
automation_enabled: true
start_keywords: ["start", "begin", "go", "play"]
pause_keywords: ["pause", "stop", "halt", "wait"]
```

## 🎯 Use Cases

- **Gaming**: Voice-controlled game actions
- **Accessibility**: Hands-free computer control
- **Productivity**: Voice-driven workflow automation
- **Presentations**: Voice-controlled slide navigation
- **Content Creation**: Voice-triggered recording controls

## 🔧 Technical Details

- **Model**: OpenAI Whisper (Base model for optimal speed/accuracy balance)
- **Audio Processing**: Real-time chunk-based transcription
- **Keyboard Automation**: AppleScript-based key simulation (macOS)
- **Threading**: Multi-threaded audio processing for responsive transcription

## 🏆 Hackathon Context

This project was developed for the **Qualcomm Edge AI Hackathon Fall 2025** to demonstrate:
- Edge AI capabilities with local processing
- Real-time speech recognition
- Voice-controlled automation
- Cross-platform compatibility

## 📝 License

MIT License - See LICENSE file for details

## 🤝 Contributing

This project was created for the Qualcomm Edge AI Hackathon. Contributions and improvements are welcome!

## 🔗 Links

- [Qualcomm AI Hub](https://aihub.qualcomm.com/)
- [OpenAI Whisper](https://github.com/openai/whisper)
- [Original Inspiration](https://github.com/thatrandomfrenchdude/simple-whisper-transcription)
