# macOS Permissions Setup for Keyboard Automation

## Required Permissions

To enable keyboard automation (pressing Enter/Escape keys when "Start"/"Pause" is detected), you need to grant the following permissions to your terminal application:

### 1. Accessibility Permissions

**Why needed**: The app uses AppleScript to simulate keyboard presses, which requires accessibility permissions.

**How to grant**:

1. **Open System Preferences/Settings**:
   - Click the Apple menu → System Preferences (or System Settings on newer macOS)
   - Go to "Security & Privacy" → "Privacy" tab

2. **Add Terminal to Accessibility**:
   - In the left sidebar, click "Accessibility"
   - Click the lock icon and enter your password
   - Click the "+" button
   - Navigate to `/Applications/Utilities/` and select "Terminal"
   - Make sure the checkbox next to "Terminal" is checked

3. **Alternative - Add Python directly**:
   - If Terminal doesn't work, you can also add Python directly:
   - Navigate to your virtual environment: `/Users/ronitgehani/Desktop/EdgeAI Whisper/simple-whisper-transcription/whisper-venv/bin/`
   - Select "python3"
   - Make sure it's checked

### 2. Test the Permissions

After granting permissions, test with this command:

```bash
cd "/Users/ronitgehani/Desktop/EdgeAI Whisper/simple-whisper-transcription"
source whisper-venv/bin/activate
python -c "import subprocess; subprocess.run(['osascript', '-e', 'tell application \"System Events\" to key code 36'], timeout=2); print('✅ Permissions working!')"
```

If you see "✅ Permissions working!" without errors, the setup is complete.

### 3. Run the Enhanced Transcription Tool

```bash
python whisper_with_macos_automation.py
```

## How It Works

### Voice Commands:
- **"Start"** (or "begin", "go", "play") → Presses **Enter** key
- **"Pause"** (or "stop", "halt", "wait") → Presses **Escape** key

### Customization:
You can modify the trigger words in `config.yaml`:

```yaml
start_keywords: ["start", "begin", "go", "play"]
pause_keywords: ["pause", "stop", "halt", "wait"]
```

## Troubleshooting

### Permission Denied Errors:
1. Make sure Terminal (or Python) is in the Accessibility list
2. Restart Terminal after adding permissions
3. Try running the test command above

### No Response to Voice Commands:
1. Check that `automation_enabled: true` in config.yaml
2. Speak clearly and wait for the transcription to appear
3. The trigger words must be in the transcribed text

### Alternative: Manual Mode
If automation doesn't work, you can still use the basic version:

```bash
python simple_whisper_transcriber.py
```

This will show transcriptions without keyboard automation.

## Security Note

The accessibility permissions allow the app to control your keyboard, so only grant these permissions to trusted applications. The app only uses these permissions to press Enter and Escape keys when specific voice commands are detected.
