# Simple Whisper Transcription - Usage Guide

## Overview
This is a simplified version of the whisper transcription tool that uses OpenAI's Whisper directly for basic transcription without requiring complex ONNX models or AI Hub dependencies.

## Setup Complete ✅
- ✅ Repository cloned
- ✅ Virtual environment created and activated
- ✅ Dependencies installed
- ✅ Configuration file created
- ✅ Whisper model tested and working

## How to Use

### 1. Activate the Virtual Environment
```bash
cd "/Users/ronitgehani/Desktop/EdgeAI Whisper/simple-whisper-transcription"
source whisper-venv/bin/activate
```

### 2. Run the Transcription Tool
```bash
python simple_whisper_transcriber.py
```

### 3. Start Speaking
- The tool will automatically start listening to your microphone
- Speak clearly and the transcription will appear in real-time
- Press `Ctrl+C` to stop the transcription

## Features
- **Real-time transcription**: Converts speech to text as you speak
- **Multiple model sizes**: Uses Whisper 'base' model (good balance of speed/accuracy)
- **Configurable settings**: Audio sample rate, chunk duration, silence threshold
- **Cross-platform**: Works on macOS, Linux, and Windows

## Configuration
The `config.yaml` file contains:
- `sample_rate`: 16000 Hz (standard for speech)
- `chunk_duration`: 4 seconds per transcription chunk
- `channels`: 1 (mono audio)
- `max_workers`: 2 parallel transcription workers
- `silence_threshold`: 0.001 (minimum audio level to process)

## Troubleshooting

### Microphone Issues
- Make sure your microphone is working and not muted
- Check system permissions for microphone access
- Try adjusting the `silence_threshold` in config.yaml

### Performance Issues
- For faster transcription, change model size to 'tiny' in the code
- For better accuracy, change model size to 'small' or 'medium'
- Adjust `max_workers` based on your CPU cores

### SSL Certificate Issues
- The tool automatically handles SSL certificate issues for model downloading
- If you encounter issues, the SSL fix is already included in the code

## Model Sizes Available
- `tiny`: Fastest, least accurate (~39MB)
- `base`: Good balance (~74MB) - **Default**
- `small`: Better accuracy (~244MB)
- `medium`: High accuracy (~769MB)
- `large`: Best accuracy (~1550MB)

## Files Created
- `simple_whisper_transcriber.py`: Main transcription tool
- `config.yaml`: Configuration settings
- `test_transcription.py`: Test script to verify setup
- `requirements_simple.txt`: Simplified dependencies
- `whisper-venv/`: Virtual environment with all packages

## Next Steps
1. Run the transcription tool: `python simple_whisper_transcriber.py`
2. Start speaking and see your words transcribed in real-time!
3. Press Ctrl+C when you're done

Enjoy your local, private speech transcription! 🎤✨
