#!/usr/bin/env python3
"""
Enhanced Whisper Transcription Tool with macOS Keyboard Automation
Uses osascript (AppleScript) for keyboard automation on macOS.
Automatically presses Enter when "Start" is detected and Escape when "Pause" is detected.
"""

import numpy as np
import sounddevice as sd
import queue
import threading
import sys
import whisper
import yaml
import os
import ssl
import time
import subprocess
from concurrent.futures import ThreadPoolExecutor

# Fix SSL certificate issue for model downloading
ssl._create_default_https_context = ssl._create_unverified_context


class WhisperTranscriberWithMacOSAutomation:
    def __init__(self, model_size="base", enable_automation=True):
        """
        Initialize the transcriber with OpenAI's Whisper model and macOS keyboard automation.
        
        Args:
            model_size: Size of the Whisper model ('tiny', 'base', 'small', 'medium', 'large')
            enable_automation: Whether to enable keyboard automation
        """
        print(f"🚀 Starting Enhanced Whisper Transcription (model: {model_size})")
        
        # Initialize automation settings
        self.enable_automation = enable_automation
        if self.enable_automation:
            print("⌨️  macOS Keyboard automation enabled (using AppleScript)")
        else:
            print("⌨️  Keyboard automation disabled")
        
        # Load configuration
        self.load_config()
        
        # Load Whisper model
        print(f"🤖 Loading Whisper {model_size} model...")
        self.model = whisper.load_model(model_size)
        print("✅ Model loaded successfully!")
        
        # Initialize audio queue and stop event
        self.audio_queue = queue.Queue()
        self.stop_event = threading.Event()
        
        print("🎯 Automation triggers:")
        print(f"   Start actions: {self.start_keywords}")
        print(f"   Pause actions: {self.pause_keywords}")
        print("   Start → Enter key")
        print("   Pause → Escape key")
        
    def load_config(self):
        """Load configuration from config.yaml or use defaults"""
        try:
            if os.path.exists("config.yaml"):
                with open("config.yaml", "r") as f:
                    config = yaml.safe_load(f)
            else:
                config = {}
                
            # Audio settings
            self.sample_rate = config.get("sample_rate", 16000)
            self.chunk_duration = config.get("chunk_duration", 4)
            self.channels = config.get("channels", 1)
            
            # Processing settings
            self.max_workers = config.get("max_workers", 2)
            self.silence_threshold = config.get("silence_threshold", 0.001)
            self.queue_timeout = config.get("queue_timeout", 1.0)
            
            # Automation settings
            self.automation_enabled = config.get("automation_enabled", True)
            self.start_keywords = config.get("start_keywords", ["start", "begin", "go", "play"])
            self.pause_keywords = config.get("pause_keywords", ["pause", "stop", "halt", "wait"])
            
            # Calculate chunk samples
            self.chunk_samples = int(self.sample_rate * self.chunk_duration)
            
            print("✅ Configuration loaded")
            
        except Exception as e:
            print(f"❌ Error loading config: {e}")
            # Use defaults
            self.sample_rate = 16000
            self.chunk_duration = 4
            self.channels = 1
            self.max_workers = 2
            self.silence_threshold = 0.001
            self.queue_timeout = 1.0
            self.chunk_samples = int(self.sample_rate * self.chunk_duration)
            self.automation_enabled = True
            self.start_keywords = ["start", "begin", "go", "play"]
            self.pause_keywords = ["pause", "stop", "halt", "wait"]
    
    def press_key_macos(self, key_name):
        """Press a key using macOS AppleScript"""
        try:
            if key_name == "enter":
                script = 'tell application "System Events" to key code 36'
            elif key_name == "escape":
                script = 'tell application "System Events" to key code 53'
            else:
                print(f"❌ Unknown key: {key_name}")
                return False
                
            # Execute AppleScript
            result = subprocess.run(
                ["osascript", "-e", script],
                capture_output=True,
                text=True,
                timeout=2
            )
            
            if result.returncode == 0:
                return True
            else:
                print(f"❌ AppleScript error: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            print(f"❌ AppleScript timeout for key: {key_name}")
            return False
        except Exception as e:
            print(f"❌ Error pressing {key_name}: {e}")
            return False
    
    def check_and_execute_automation(self, transcript):
        """Check transcript for automation triggers and execute actions"""
        if not self.enable_automation or not self.automation_enabled:
            return
            
        transcript_lower = transcript.lower().strip()
        
        # Check for start keywords
        for keyword in self.start_keywords:
            if keyword in transcript_lower:
                print(f"🚀 START detected: '{keyword}' → Pressing Enter")
                sys.stdout.flush()
                if self.press_key_macos("enter"):
                    time.sleep(0.1)  # Small delay to avoid rapid key presses
                return
        
        # Check for pause keywords
        for keyword in self.pause_keywords:
            if keyword in transcript_lower:
                print(f"⏸️  PAUSE detected: '{keyword}' → Pressing Escape")
                sys.stdout.flush()
                if self.press_key_macos("escape"):
                    time.sleep(0.1)  # Small delay to avoid rapid key presses
                return
    
    def transcribe_audio(self, audio_chunk):
        """Transcribe a chunk of audio"""
        try:
            # Check if audio has enough volume
            if np.abs(audio_chunk).mean() > self.silence_threshold:
                # Transcribe using Whisper
                result = self.model.transcribe(audio_chunk, fp16=False)
                transcript = result["text"].strip()
                
                if transcript:
                    print(f"📝 Transcript: {transcript}")
                    sys.stdout.flush()
                    
                    # Check for automation triggers
                    self.check_and_execute_automation(transcript)
                    
        except Exception as e:
            print(f"❌ Transcription error: {e}")
            sys.stdout.flush()
    
    def process_audio_queue(self):
        """Process audio chunks from the queue"""
        buffer = np.empty((0,), dtype=np.float32)
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = []
            
            while not self.stop_event.is_set():
                try:
                    # Get audio chunk from queue
                    audio_chunk = self.audio_queue.get(timeout=self.queue_timeout)
                    audio_chunk = audio_chunk.flatten()
                    buffer = np.concatenate([buffer, audio_chunk])
                    
                    # Process complete chunks
                    while len(buffer) >= self.chunk_samples:
                        current_chunk = buffer[:self.chunk_samples]
                        buffer = buffer[self.chunk_samples:]
                        
                        # Submit transcription task
                        future = executor.submit(self.transcribe_audio, current_chunk)
                        futures.append(future)
                        
                        # Clean up completed futures
                        futures = [f for f in futures if not f.done()]
                        
                except queue.Empty:
                    continue
                except Exception as e:
                    print(f"❌ Audio processing error: {e}")
                    sys.stdout.flush()
            
            # Wait for remaining transcription tasks
            for future in futures:
                try:
                    future.result()
                except Exception as e:
                    print(f"❌ Future result error: {e}")
                    sys.stdout.flush()
    
    def audio_callback(self, indata, frames, time, status):
        """Callback for audio input stream"""
        if not self.stop_event.is_set():
            self.audio_queue.put(indata.copy())
    
    def record_audio(self):
        """Record audio from microphone"""
        try:
            with sd.InputStream(
                samplerate=self.sample_rate,
                channels=self.channels,
                callback=self.audio_callback
            ):
                print("🎤 Microphone active - Start speaking! (Press Ctrl+C to stop)")
                print("=" * 60)
                if self.enable_automation:
                    print("🎯 Say 'start' to press Enter, 'pause' to press Escape")
                    print("⚠️  Note: You may need to grant accessibility permissions")
                    print("=" * 60)
                sys.stdout.flush()
                self.stop_event.wait()
                
        except Exception as e:
            print(f"❌ Audio recording error: {e}")
            sys.stdout.flush()
    
    def run(self):
        """Run the live transcription"""
        try:
            # Start audio processing thread
            process_thread = threading.Thread(target=self.process_audio_queue)
            process_thread.start()
            
            # Start audio recording thread
            record_thread = threading.Thread(target=self.record_audio)
            record_thread.start()
            
            # Wait for threads to finish
            try:
                while True:
                    record_thread.join(timeout=0.1)
                    if not record_thread.is_alive():
                        break
            except KeyboardInterrupt:
                print("\n🛑 Stopping transcription...")
                sys.stdout.flush()
            finally:
                self.stop_event.set()
                record_thread.join()
                process_thread.join()
                
        except Exception as e:
            print(f"❌ Runtime error: {e}")
            sys.stdout.flush()


def main():
    """Main function"""
    print("Enhanced Whisper Transcription Tool with macOS Keyboard Automation")
    print("Available models: tiny, base, small, medium, large")
    print("Note: Larger models are more accurate but slower")
    print()
    
    # Get model size from user or use default
    model_size = "base"  # Default to base model for good balance of speed/accuracy
    
    try:
        transcriber = WhisperTranscriberWithMacOSAutomation(model_size, enable_automation=True)
        transcriber.run()
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")
    except Exception as e:
        print(f"❌ Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
