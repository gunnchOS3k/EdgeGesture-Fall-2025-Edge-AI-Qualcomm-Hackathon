#!/usr/bin/env python3
"""
Simple Whisper Transcription Tool
A simplified version that uses OpenAI's Whisper directly for basic transcription.
"""

import numpy as np
import sounddevice as sd
import queue
import threading
import sys
import whisper
import yaml
import os
import ssl
from concurrent.futures import ThreadPoolExecutor

# Fix SSL certificate issue for model downloading
ssl._create_default_https_context = ssl._create_unverified_context


class SimpleWhisperTranscriber:
    def __init__(self, model_size="base"):
        """
        Initialize the transcriber with OpenAI's Whisper model.
        
        Args:
            model_size: Size of the Whisper model ('tiny', 'base', 'small', 'medium', 'large')
        """
        print(f"🚀 Starting Simple Whisper Transcription (model: {model_size})")
        
        # Load configuration
        self.load_config()
        
        # Load Whisper model
        print(f"🤖 Loading Whisper {model_size} model...")
        self.model = whisper.load_model(model_size)
        print("✅ Model loaded successfully!")
        
        # Initialize audio queue and stop event
        self.audio_queue = queue.Queue()
        self.stop_event = threading.Event()
        
    def load_config(self):
        """Load configuration from config.yaml or use defaults"""
        try:
            if os.path.exists("config.yaml"):
                with open("config.yaml", "r") as f:
                    config = yaml.safe_load(f)
            else:
                config = {}
                
            # Audio settings
            self.sample_rate = config.get("sample_rate", 16000)
            self.chunk_duration = config.get("chunk_duration", 4)
            self.channels = config.get("channels", 1)
            
            # Processing settings
            self.max_workers = config.get("max_workers", 2)
            self.silence_threshold = config.get("silence_threshold", 0.001)
            self.queue_timeout = config.get("queue_timeout", 1.0)
            
            # Calculate chunk samples
            self.chunk_samples = int(self.sample_rate * self.chunk_duration)
            
            print("✅ Configuration loaded")
            
        except Exception as e:
            print(f"❌ Error loading config: {e}")
            # Use defaults
            self.sample_rate = 16000
            self.chunk_duration = 4
            self.channels = 1
            self.max_workers = 2
            self.silence_threshold = 0.001
            self.queue_timeout = 1.0
            self.chunk_samples = int(self.sample_rate * self.chunk_duration)
    
    def transcribe_audio(self, audio_chunk):
        """Transcribe a chunk of audio"""
        try:
            # Check if audio has enough volume
            if np.abs(audio_chunk).mean() > self.silence_threshold:
                # Transcribe using Whisper
                result = self.model.transcribe(audio_chunk, fp16=False)
                transcript = result["text"].strip()
                
                if transcript:
                    print(f"📝 Transcript: {transcript}")
                    sys.stdout.flush()
                    
        except Exception as e:
            print(f"❌ Transcription error: {e}")
            sys.stdout.flush()
    
    def process_audio_queue(self):
        """Process audio chunks from the queue"""
        buffer = np.empty((0,), dtype=np.float32)
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = []
            
            while not self.stop_event.is_set():
                try:
                    # Get audio chunk from queue
                    audio_chunk = self.audio_queue.get(timeout=self.queue_timeout)
                    audio_chunk = audio_chunk.flatten()
                    buffer = np.concatenate([buffer, audio_chunk])
                    
                    # Process complete chunks
                    while len(buffer) >= self.chunk_samples:
                        current_chunk = buffer[:self.chunk_samples]
                        buffer = buffer[self.chunk_samples:]
                        
                        # Submit transcription task
                        future = executor.submit(self.transcribe_audio, current_chunk)
                        futures.append(future)
                        
                        # Clean up completed futures
                        futures = [f for f in futures if not f.done()]
                        
                except queue.Empty:
                    continue
                except Exception as e:
                    print(f"❌ Audio processing error: {e}")
                    sys.stdout.flush()
            
            # Wait for remaining transcription tasks
            for future in futures:
                try:
                    future.result()
                except Exception as e:
                    print(f"❌ Future result error: {e}")
                    sys.stdout.flush()
    
    def audio_callback(self, indata, frames, time, status):
        """Callback for audio input stream"""
        if not self.stop_event.is_set():
            self.audio_queue.put(indata.copy())
    
    def record_audio(self):
        """Record audio from microphone"""
        try:
            with sd.InputStream(
                samplerate=self.sample_rate,
                channels=self.channels,
                callback=self.audio_callback
            ):
                print("🎤 Microphone active - Start speaking! (Press Ctrl+C to stop)")
                print("=" * 60)
                sys.stdout.flush()
                self.stop_event.wait()
                
        except Exception as e:
            print(f"❌ Audio recording error: {e}")
            sys.stdout.flush()
    
    def run(self):
        """Run the live transcription"""
        try:
            # Start audio processing thread
            process_thread = threading.Thread(target=self.process_audio_queue)
            process_thread.start()
            
            # Start audio recording thread
            record_thread = threading.Thread(target=self.record_audio)
            record_thread.start()
            
            # Wait for threads to finish
            try:
                while True:
                    record_thread.join(timeout=0.1)
                    if not record_thread.is_alive():
                        break
            except KeyboardInterrupt:
                print("\n🛑 Stopping transcription...")
                sys.stdout.flush()
            finally:
                self.stop_event.set()
                record_thread.join()
                process_thread.join()
                
        except Exception as e:
            print(f"❌ Runtime error: {e}")
            sys.stdout.flush()


def main():
    """Main function"""
    print("Simple Whisper Transcription Tool")
    print("Available models: tiny, base, small, medium, large")
    print("Note: Larger models are more accurate but slower")
    print()
    
    # Get model size from user or use default
    model_size = "base"  # Default to base model for good balance of speed/accuracy
    
    try:
        transcriber = SimpleWhisperTranscriber(model_size)
        transcriber.run()
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")
    except Exception as e:
        print(f"❌ Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
