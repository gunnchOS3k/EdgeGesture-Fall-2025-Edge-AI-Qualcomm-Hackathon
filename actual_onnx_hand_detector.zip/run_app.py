#!/usr/bin/env python3
"""
Main launcher for the Gesture-to-Keyboard Controller.
This script helps with camera permissions and allows users to select different game modes.
"""

import subprocess
import sys
import os
import webbrowser
import time

def check_camera_permissions():
    """Check if camera permissions are granted."""
    print("Checking camera permissions...")
    
    # Try to import and test camera access
    try:
        import cv2
        cap = cv2.VideoCapture(0) 
        if cap.isOpened():
            ret, frame = cap.read()
            cap.release()
            if ret:
                print("✓ Camera permissions are granted!")
                return True
            else:
                print("✗ Camera opened but cannot read frames")
                return False
        else:
            print("✗ Camera access denied")
            return False
    except Exception as e:
        print(f"✗ Camera test failed: {e}")
        return False

def request_camera_permissions():
    """Request camera permissions."""
    print("\n" + "="*60)
    print("CAMERA PERMISSION REQUIRED")
    print("="*60)
    print("To use the gesture controller, you need to grant camera access.")
    print("\nFollow these steps:")
    print("1. A dialog should appear asking for camera permission")
    print("2. If not, go to: Settings > Privacy & Security > Camera")
    print("3. Find 'Python' or your terminal application in the list and enable it")
    print("4. Restart the application")
    print("="*60)

def show_menu():
    """Display the main menu and get user selection."""
    print("\n" + "="*50)
    print("GESTURE-TO-KEYBOARD CONTROLLER")
    print("="*50)
    print("Select a game mode:")
    print("1. Pong Game (Browser-based)")
    print("2. Shooting Game (FPS/Shooter)")
    print("3. Mouse Control (General mouse control)")
    print("4. Exit")
    print("="*50)
    
    while True:
        try:
            choice = input("\nEnter your choice (1-4): ").strip()
            if choice in ['1', '2', '3', '4']:
                return choice
            else:
                print("Please enter a valid choice (1-4)")
        except KeyboardInterrupt:
            print("\nExiting...")
            return '4'

def main():
    """Main function to run the gesture controller launcher."""
    print("Gesture-to-Keyboard Controller Launcher")
    print("="*40)
    
    # Use the current Python interpreter
    python_path = sys.executable
    print(f"Using Python at: {python_path}")
    
    # Check camera permissions
    if not check_camera_permissions():
        request_camera_permissions()
        print("\nAfter granting permissions, run this script again.")
        return
    
    while True:
        choice = show_menu()
        
        if choice == '1':
            # Pong game
            print("\nStarting Pong game mode...")
            try:
                pong_path = os.path.join(os.path.dirname(__file__), "pong.py")
                subprocess.run([python_path, pong_path], check=True)
            except KeyboardInterrupt:
                print("\nPong mode interrupted by user")
            except subprocess.CalledProcessError as e:
                print(f"Pong mode failed with error: {e}")
            except Exception as e:
                print(f"Unexpected error in Pong mode: {e}")
                
        elif choice == '2':
            # Shooting game
            print("\nStarting Shooting game mode...")
            try:
                shooting_path = os.path.join(os.path.dirname(__file__), "shooting.py")
                subprocess.run([python_path, shooting_path], check=True)
            except KeyboardInterrupt:
                print("\nShooting mode interrupted by user")
            except subprocess.CalledProcessError as e:
                print(f"Shooting mode failed with error: {e}")
            except Exception as e:
                print(f"Unexpected error in Shooting mode: {e}")
                
        elif choice == '3':
            # Mouse control
            print("\nStarting Mouse control mode...")
            try:
                mouse_path = os.path.join(os.path.dirname(__file__), "control_mouse.py")
                subprocess.run([python_path, mouse_path], check=True)
            except KeyboardInterrupt:
                print("\nMouse control mode interrupted by user")
            except subprocess.CalledProcessError as e:
                print(f"Mouse control mode failed with error: {e}")
            except Exception as e:
                print(f"Unexpected error in Mouse control mode: {e}")
                
        elif choice == '4':
            print("\nGoodbye!")
            break
        
        # Ask if user wants to continue
        if choice != '4':
            try:
                continue_choice = input("\nDo you want to return to the main menu? (y/n): ").strip().lower()
                if continue_choice not in ['y', 'yes']:
                    break
            except KeyboardInterrupt:
                break

if __name__ == "__main__":
    main()