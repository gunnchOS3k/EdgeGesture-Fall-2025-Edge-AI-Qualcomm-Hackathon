#!/usr/bin/env python3
"""
Download actual ONNX models for MediaPipe and Whisper
"""

import os
import sys
import requests
import zipfile
import shutil
from pathlib import Path
import subprocess

def download_mediapipe_onnx_models():
    """Download MediaPipe ONNX models for hand detection."""
    print("📥 Downloading MediaPipe ONNX models...")
    
    models_dir = Path("models")
    models_dir.mkdir(exist_ok=True)
    
    # MediaPipe hand landmark ONNX model URLs
    model_urls = {
        "hand_landmark.onnx": "https://github.com/google/mediapipe/raw/master/mediapipe/modules/hand_landmark/hand_landmark.onnx",
        "palm_detection.onnx": "https://github.com/google/mediapipe/raw/master/mediapipe/modules/palm_detection/palm_detection.onnx"
    }
    
    for filename, url in model_urls.items():
        filepath = models_dir / filename
        if not filepath.exists():
            print(f"   Downloading {filename}...")
            try:
                response = requests.get(url, stream=True)
                response.raise_for_status()
                
                with open(filepath, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                print(f"   ✅ Downloaded {filename}")
            except Exception as e:
                print(f"   ❌ Failed to download {filename}: {e}")
        else:
            print(f"   ✅ {filename} already exists")

def download_whisper_onnx_models():
    """Download Whisper ONNX models."""
    print("📥 Downloading Whisper ONNX models...")
    
    models_dir = Path("models")
    models_dir.mkdir(exist_ok=True)
    
    # Try to convert Whisper to ONNX using optimum
    try:
        print("   Converting Whisper to ONNX using optimum...")
        subprocess.run([
            sys.executable, "-m", "pip", "install", "optimum[onnxruntime]"
        ], check=True)
        
        # Convert Whisper base model to ONNX
        subprocess.run([
            sys.executable, "-c", 
            """
from optimum.onnxruntime import ORTModelForSpeechSeq2Seq
from transformers import AutoTokenizer
import os

model_name = "openai/whisper-base"
output_dir = "models/whisper_onnx"

print(f"Converting {model_name} to ONNX...")
model = ORTModelForSpeechSeq2Seq.from_pretrained(model_name, export=True)
tokenizer = AutoTokenizer.from_pretrained(model_name)

model.save_pretrained(output_dir)
tokenizer.save_pretrained(output_dir)
print("Whisper ONNX model saved successfully!")
            """
        ], check=True)
        
        print("   ✅ Whisper ONNX model converted successfully")
        
    except Exception as e:
        print(f"   ❌ Failed to convert Whisper to ONNX: {e}")
        print("   💡 Will use original Whisper as fallback")

def download_alternative_models():
    """Download alternative ONNX models if primary ones fail."""
    print("📥 Downloading alternative ONNX models...")
    
    models_dir = Path("models")
    models_dir.mkdir(exist_ok=True)
    
    # Alternative hand detection ONNX model
    try:
        print("   Downloading alternative hand detection model...")
        # This is a placeholder - you would use actual ONNX model URLs
        print("   💡 Alternative models would be downloaded here")
    except Exception as e:
        print(f"   ❌ Alternative model download failed: {e}")

def verify_models():
    """Verify that downloaded models are valid ONNX files."""
    print("🔍 Verifying ONNX models...")
    
    models_dir = Path("models")
    onnx_files = list(models_dir.glob("*.onnx"))
    
    if not onnx_files:
        print("   ❌ No ONNX models found")
        return False
    
    try:
        import onnxruntime as ort
        
        for model_file in onnx_files:
            try:
                session = ort.InferenceSession(str(model_file))
                print(f"   ✅ {model_file.name} is valid ONNX model")
                print(f"      Inputs: {[inp.name for inp in session.get_inputs()]}")
                print(f"      Outputs: {[out.name for out in session.get_outputs()]}")
            except Exception as e:
                print(f"   ❌ {model_file.name} is not valid ONNX: {e}")
        
        return True
        
    except ImportError:
        print("   ❌ ONNX Runtime not available for verification")
        return False

def main():
    """Main download function."""
    print("🚀 Downloading ONNX Models for EdgeGesture")
    print("=" * 50)
    
    # Download MediaPipe ONNX models
    download_mediapipe_onnx_models()
    
    # Download Whisper ONNX models
    download_whisper_onnx_models()
    
    # Download alternative models if needed
    download_alternative_models()
    
    # Verify models
    verify_models()
    
    print("\n✅ ONNX model download completed!")
    print("\n📋 Next steps:")
    print("1. Update hand detector to use downloaded ONNX models")
    print("2. Update Whisper transcriber to use ONNX models")
    print("3. Test performance improvements")

if __name__ == "__main__":
    main()
