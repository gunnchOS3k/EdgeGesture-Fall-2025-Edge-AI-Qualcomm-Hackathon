#!/usr/bin/env python3
"""
Mouse Control Gesture Controller Module.
Handles gesture-to-mouse mapping for general mouse control.
"""

import cv2
import numpy as np
import sys
import time
import pyautogui
from optimized_hand_detector import OptimizedHandDetector
from pynput.mouse import Button, Controller as MouseController

class MouseGestureController:
    def __init__(self):
        """Initialize the mouse gesture controller."""
        self.hand_detector = OptimizedHandDetector(use_onnx=True)
        self.mouse = MouseController()
        self.cap = None
        self.running = False
        
        # Mouse control state
        self.mouse_pressed = False
        self.last_finger_pos = None
        self.mouse_sensitivity = 0.8  # Adjust this to change mouse sensitivity (increased for faster movement)
        self.center_x = 320  # Center of camera frame
        self.center_y = 240  # Center of camera frame
        
        # Get screen dimensions
        self.screen_width, self.screen_height = pyautogui.size()
        
        # Optimized timing for high-frequency gesture detection
        self.last_operation_time = 0
        self.last_click_time = 0
        self.operation_delay = 0.001  # 1ms delay between operations (minimal)
        self.click_delay = 0.05  # 50ms delay between clicks (very fast for games)
        
        # Frame processing optimization
        self.frame_skip_count = 0
        self.frame_skip_interval = 1  # Process every frame (no skipping initially)
        self.last_gesture_time = 0
        self.gesture_update_interval = 0.001  # 1ms between gesture updates
        self.debug_mode = False  # Toggle for debug information
        
    def initialize_camera(self) -> bool:
        """Initialize the webcam."""
        try:
            self.cap = cv2.VideoCapture(0)
            if not self.cap.isOpened():
                print("Error: Could not open webcam")
                return False
            
            # Set camera properties for maximum performance
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self.cap.set(cv2.CAP_PROP_FPS, 120)  # Maximum FPS for gesture detection
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # Minimal buffer for lowest latency
            self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))  # Use MJPEG for better performance
            
            print("Camera initialized successfully")
            return True
        except Exception as e:
            print(f"Error initializing camera: {e}")
            return False
    
    def detect_mouse_gestures(self, frame):
        """Detect hand gestures for mouse control with optimized processing."""
        # Detect hand and get gesture information
        index_finger_pos, is_fist, annotated_frame, thumb_pos = self.hand_detector.detect_hand(frame)
        
        gesture_type = 'none'
        middle_pos = None
        
        if index_finger_pos and thumb_pos:
            # Calculate middle point between thumb and index finger (optimized)
            middle_pos = (
                (index_finger_pos[0] + thumb_pos[0]) >> 1,  # Bit shift instead of division
                (index_finger_pos[1] + thumb_pos[1]) >> 1
            )
            
            # Check if thumb and index finger are touching (optimized distance calculation)
            dx = index_finger_pos[0] - thumb_pos[0]
            dy = index_finger_pos[1] - thumb_pos[1]
            distance_squared = dx * dx + dy * dy  # Avoid sqrt for performance
            
            if distance_squared < 900:  # 30^2 = 900 (threshold for "touching")
                gesture_type = 'touch'  # Click
            else:
                gesture_type = 'pointing'  # Just move mouse
            
            # Store distance for debugging (only when needed)
            if hasattr(self, 'debug_mode') and self.debug_mode:
                self.last_distance = distance_squared ** 0.5
        elif index_finger_pos:
            # Fallback to index finger only if thumb not detected
            middle_pos = index_finger_pos
            gesture_type = 'pointing'
        
        return gesture_type, middle_pos, annotated_frame, thumb_pos
    
    def handle_mouse_gestures(self, gesture_type, finger_pos):
        """Handle the detected gestures and control the mouse."""
        current_time = time.time()
        
        # Only process if enough time has passed since last operation
        if current_time - self.last_operation_time < self.operation_delay:
            return
        
        if gesture_type == 'pointing' and finger_pos:
            # Just move mouse - no clicking
            self.move_mouse(finger_pos)
            
        elif gesture_type == 'touch' and finger_pos:
            # Move mouse and perform single click when thumb touches index finger
            self.move_mouse(finger_pos)
            # Add a delay to prevent too many clicks
            if current_time - self.last_click_time > self.click_delay:
                try:
                    self.mouse.click(Button.left, 1)
                    print("Mouse clicked (thumb + index touch)")
                    self.last_click_time = current_time
                except Exception as e:
                    print(f"Error clicking mouse: {e}")
            
        elif gesture_type == 'none' or not finger_pos:
            # No hand detected - do nothing
            pass
        
        self.last_operation_time = current_time
    
    def move_mouse(self, finger_pos):
        """Move mouse based on finger position using optimized linear movement."""
        if not finger_pos:
            return
        
        x, y = finger_pos
        
        # Calculate distance from center (optimized)
        dx = x - self.center_x
        dy = y - self.center_y
        distance_squared = dx * dx + dy * dy
        
        # Optimized sensitivity curve with much slower movement near center for precision
        if distance_squared < 400:  # 20^2 - Very close to center
            adaptive_sensitivity = self.mouse_sensitivity * 0.1  # 10% for high precision
        elif distance_squared < 1600:  # 40^2 - Close to center
            adaptive_sensitivity = self.mouse_sensitivity * 0.2  # 20% for precision
        elif distance_squared < 3600:  # 60^2 - Medium close
            adaptive_sensitivity = self.mouse_sensitivity * 0.4  # 40% for medium precision
        elif distance_squared < 10000:  # 100^2 - Medium distance
            adaptive_sensitivity = self.mouse_sensitivity * 0.7  # 70% for normal movement
        else:  # Far from center
            adaptive_sensitivity = self.mouse_sensitivity  # Full sensitivity
        
        # Calculate movement with linear sensitivity
        delta_x = dx * adaptive_sensitivity
        delta_y = dy * adaptive_sensitivity
        
        # Reduced threshold for more responsive movement
        if abs(delta_x) > 0.3 or abs(delta_y) > 0.3:  # Even lower threshold
            try:
                self.mouse.move(delta_x, delta_y)
            except Exception as e:
                if self.debug_mode:
                    print(f"Error moving mouse: {e}")
        
        # Store for debugging (only when debug mode is on)
        if self.debug_mode:
            self.last_adaptive_sensitivity = adaptive_sensitivity
            self.last_distance_from_center = distance_squared ** 0.5
    
    def draw_debug_overlay(self, frame: np.ndarray, gesture_type: str, 
                          finger_pos: tuple, thumb_pos: tuple = None) -> np.ndarray:
        """
        Draw debug overlay on the frame for mouse control.
        
        Args:
            frame: Input frame
            gesture_type: Type of gesture detected
            finger_pos: Position of index finger
            
        Returns:
            Frame with debug overlay
        """
        h, w = frame.shape[:2]
        
        # Draw gesture information
        if gesture_type == 'pointing':
            gesture_color = (0, 255, 255)  # Yellow for pointing
        elif gesture_type == 'touch':
            gesture_color = (0, 255, 0)    # Green for touch/click
        elif gesture_type == 'none':
            gesture_color = (128, 128, 128)  # Gray for none
        else:
            gesture_color = (0, 255, 0)    # Green for other
            
        cv2.putText(frame, f"Gesture: {gesture_type.upper()}", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, gesture_color, 2)
        
        # Add touch detection info
        if gesture_type == 'touch':
            cv2.putText(frame, "TOUCH DETECTED - CLICKING!", (10, 90), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        
        # Add distance info for debugging
        if hasattr(self, 'last_distance'):
            cv2.putText(frame, f"Finger distance: {self.last_distance:.1f}px", (10, 120), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            cv2.putText(frame, "Touch threshold: <30px", (10, 140), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        
        # Add adaptive sensitivity info
        if hasattr(self, 'last_adaptive_sensitivity') and hasattr(self, 'last_distance_from_center'):
            cv2.putText(frame, f"Center distance: {self.last_distance_from_center:.1f}px", (10, 160), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            cv2.putText(frame, f"Sensitivity: {self.last_adaptive_sensitivity:.2f}", (10, 180), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        # Draw mouse state
        mouse_state = "PRESSED" if self.mouse_pressed else "RELEASED"
        mouse_color = (0, 0, 255) if self.mouse_pressed else (0, 255, 0)
        cv2.putText(frame, f"Mouse: {mouse_state}", (10, 60), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, mouse_color, 2)
        
        # Draw center point and sensitivity zones
        cv2.circle(frame, (self.center_x, self.center_y), 5, (0, 255, 255), -1)
        cv2.putText(frame, "CENTER", (self.center_x + 10, self.center_y - 10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 255), 1)
        
        # Draw sensitivity zones (updated for new precision levels)
        cv2.circle(frame, (self.center_x, self.center_y), 20, (0, 255, 0), 1)  # High precision zone (10%)
        cv2.circle(frame, (self.center_x, self.center_y), 40, (0, 255, 0), 1)  # Precision zone (20%)
        cv2.circle(frame, (self.center_x, self.center_y), 60, (0, 255, 255), 1)  # Medium precision zone (40%)
        cv2.circle(frame, (self.center_x, self.center_y), 100, (0, 165, 255), 1)  # Normal speed zone (70%)
        
        # Draw thumb position
        if thumb_pos:
            tx, ty = thumb_pos
            cv2.circle(frame, (tx, ty), 8, (255, 0, 0), -1)  # Blue circle for thumb
            cv2.putText(frame, "THUMB", (tx + 10, ty - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 0, 0), 1)
        
        # Draw middle point (mouse control point)
        if finger_pos:
            x, y = finger_pos
            cv2.circle(frame, (x, y), 12, (0, 255, 0), -1)  # Green circle for middle point
            cv2.putText(frame, "MIDDLE", (x + 15, y - 15), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
            
            # Draw line from center to middle point
            cv2.line(frame, (self.center_x, self.center_y), (x, y), (255, 0, 0), 2)
            
            # Draw line between thumb and index finger if both are visible
            if thumb_pos:
                cv2.line(frame, thumb_pos, finger_pos, (255, 255, 0), 2)  # Yellow line
        
        # Draw control instructions
        cv2.putText(frame, "MOUSE CONTROL:", (10, h - 120), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(frame, "1. Move hand = Move mouse", (10, h - 100), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        cv2.putText(frame, "2. Touch thumb+index = Click", (10, h - 80), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        cv2.putText(frame, "3. No hand = Do nothing", (10, h - 60), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (128, 128, 128), 1)
        
        # Draw sensitivity info
        cv2.putText(frame, f"Sensitivity: {self.mouse_sensitivity:.1f}", (w - 200, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(frame, "Press +/- to adjust", (w - 200, 50), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        
        cv2.putText(frame, "Press 'q' to quit", (10, h - 10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        return frame
    
    def run(self):
        """Main application loop for mouse control."""
        print("Advanced Mouse Control with Adaptive Sensitivity")
        print("===============================================")
        print("Gestures:")
        print("1. Move hand = Move mouse (uses middle of thumb + index finger)")
        print("2. Touch thumb to index finger = Left click")
        print("3. No hand = Do nothing")
        print()
        print("Adaptive Sensitivity:")
        print("- Close to center = High precision (slow movement)")
        print("- Far from center = Fast movement")
        print()
        print("Visual Guide:")
        print("- Blue circle = Thumb position")
        print("- Green circle = Mouse control point (middle)")
        print("- Yellow line = Connection between thumb and index")
        print("- Green rings = High precision zones (10% and 20% sensitivity)")
        print("- Yellow ring = Medium precision zone (40% sensitivity)")
        print("- Orange ring = Normal speed zone (70% sensitivity)")
        print()
        print("Controls:")
        print("- Press +/- to adjust base sensitivity")
        print("- Press 'c' to reset center point")
        print("- Press 'd' to toggle debug mode")
        print("- Press 'r' to reset mouse state")
        print("- Press 'q' to quit")
        print()
        
        if not self.initialize_camera():
            return
        
        self.running = True
        
        try:
            while self.running:
                ret, frame = self.cap.read()
                if not ret:
                    print("Error: Could not read frame from camera")
                    break
                
                # Flip frame horizontally for mirror effect
                frame = cv2.flip(frame, 1)
                
                # Frame skipping for performance (process every frame for maximum responsiveness)
                self.frame_skip_count += 1
                if self.frame_skip_count % self.frame_skip_interval == 0:
                    # Detect mouse gestures with high frequency
                    gesture_type, finger_pos, annotated_frame, thumb_pos = self.detect_mouse_gestures(frame)
                    
                    # Handle gestures with minimal delay
                    current_time = time.time()
                    if current_time - self.last_gesture_time >= self.gesture_update_interval:
                        self.handle_mouse_gestures(gesture_type, finger_pos)
                        self.last_gesture_time = current_time
                else:
                    # Use previous frame data for display
                    gesture_type, finger_pos, annotated_frame, thumb_pos = 'none', None, frame, None
                
                # Draw debug overlay (less frequently to save processing)
                if self.frame_skip_count % 2 == 0:  # Draw every other frame
                    debug_frame = self.draw_debug_overlay(
                        annotated_frame, gesture_type, finger_pos, thumb_pos
                    )
                else:
                    debug_frame = annotated_frame
                
                # Display the frame
                cv2.imshow('Mouse Control Gesture Controller', debug_frame)
                
                # Check for quit command and sensitivity adjustment (non-blocking)
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    self.running = False
                elif key == ord('+') or key == ord('='):
                    self.mouse_sensitivity = min(self.mouse_sensitivity + 0.1, 5.0)
                    print(f"Sensitivity increased to {self.mouse_sensitivity:.1f}")
                elif key == ord('-'):
                    self.mouse_sensitivity = max(self.mouse_sensitivity - 0.1, 0.1)
                    print(f"Sensitivity decreased to {self.mouse_sensitivity:.1f}")
                elif key == ord('r'):
                    # Reset mouse state
                    if self.mouse_pressed:
                        self.mouse.release(Button.left)
                        self.mouse_pressed = False
                        print("Mouse reset - released")
                elif key == ord('c'):
                    # Reset center point
                    if finger_pos:
                        self.center_x, self.center_y = finger_pos
                        print(f"Center point reset to ({self.center_x}, {self.center_y})")
                elif key == ord('d'):
                    # Toggle debug mode
                    self.debug_mode = not self.debug_mode
                    print(f"Debug mode: {'ON' if self.debug_mode else 'OFF'}")
        
        except KeyboardInterrupt:
            print("\nApplication interrupted by user")
        
        finally:
            self.cleanup()
    
    def cleanup(self):
        """Clean up resources."""
        print("Cleaning up...")
        
        # Release mouse if still pressed
        if self.mouse_pressed:
            self.mouse.release(Button.left)
            self.mouse_pressed = False
        
        if self.cap:
            self.cap.release()
        
        cv2.destroyAllWindows()
        print("Cleanup complete")

def main():
    """Main entry point for mouse control mode."""
    app = MouseGestureController()
    app.run()

if __name__ == "__main__":
    main()
