#!/usr/bin/env python3
"""
Shooting Game Gesture Controller Module.
Handles gesture-to-keyboard mapping for shooting games (FPS/Shooter).
"""

import cv2
import numpy as np
import sys
import time
from optimized_hand_detector import OptimizedHandDetector
from pynput.keyboard import Key, Controller
from pynput.mouse import Button, Listener as MouseListener

class ShootingGestureController:
    def __init__(self):
        """Initialize the shooting game gesture controller."""
        self.hand_detector = OptimizedHandDetector(use_onnx=True)
        self.keyboard = Controller()
        self.cap = None
        self.running = False
        
        # Track currently pressed keys to avoid redundant key presses
        self.current_keys = set()
        
        # Key mappings for shooting games
        self.KEY_MAPPINGS = {
            'w': Key.w,      # Move forward
            's': Key.s,      # Move backward
            'space': Key.space,  # Jump
            'r': Key.r       # Reload
        }
        
        # Mouse button mappings
        self.MOUSE_LEFT = Button.left
        self.MOUSE_RIGHT = Button.right
        
        # Small delay to prevent too rapid key presses
        self.last_key_time = 0
        self.key_delay = 0.05  # 50ms delay between key operations
        
    def initialize_camera(self) -> bool:
        """Initialize the webcam."""
        try:
            self.cap = cv2.VideoCapture(0)
            if not self.cap.isOpened():
                print("Error: Could not open webcam")
                return False
            
            # Set camera properties for better performance
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self.cap.set(cv2.CAP_PROP_FPS, 30)
            
            print("Camera initialized successfully")
            return True
        except Exception as e:
            print(f"Error initializing camera: {e}")
            return False
    
    def detect_hand_gestures(self, frame):
        """Detect hand gestures for shooting game controls."""
        # Detect both hands
        left_hand_gesture = None
        right_hand_gesture = None
        
        # This is a simplified version - in a real implementation, you'd need
        # to modify the hand detector to detect both hands and their gestures
        index_finger_pos, is_fist, annotated_frame, thumb_pos = self.hand_detector.detect_hand(frame)
        
        # For now, we'll use the single hand detection and map it to different gestures
        # In a full implementation, you'd want to detect both hands separately
        
        # Simulate left hand gestures (movement)
        if index_finger_pos:
            x_pos = index_finger_pos[0]
            screen_region = self.hand_detector.get_screen_region(x_pos, frame.shape[1])
            
            if screen_region == 'left':
                left_hand_gesture = 'open_palm'  # Move forward
            elif screen_region == 'right':
                left_hand_gesture = 'fist'  # Move backward
            else:
                left_hand_gesture = 'middle'  # No movement
        
        # Simulate right hand gestures (shooting)
        if is_fist:
            right_hand_gesture = 'fist'  # Reload
        else:
            right_hand_gesture = 'open_palm'  # Aim down sights
            # Index finger pointing would be detected separately for shooting
        
        return left_hand_gesture, right_hand_gesture, annotated_frame
    
    def handle_gestures(self, left_gesture, right_gesture):
        """Handle the detected gestures and send appropriate commands."""
        current_time = time.time()
        
        # Only process if enough time has passed since last key operation
        if current_time - self.last_key_time < self.key_delay:
            return
            
        # Determine which keys should be pressed based on gestures
        target_keys = set()
        
        # Left hand controls (movement)
        if left_gesture == 'open_palm':
            target_keys.add(self.KEY_MAPPINGS['w'])  # Move forward
        elif left_gesture == 'fist':
            target_keys.add(self.KEY_MAPPINGS['s'])  # Move backward
        # For 'middle', we don't add any movement keys
        
        # Right hand controls (shooting)
        if right_gesture == 'open_palm':
            # Aim down sights (right mouse button)
            try:
                from pynput.mouse import Controller as MouseController
                mouse = MouseController()
                mouse.press(self.MOUSE_RIGHT)
                print("Aiming down sights")
            except Exception as e:
                print(f"Error aiming: {e}")
        elif right_gesture == 'fist':
            target_keys.add(self.KEY_MAPPINGS['r'])  # Reload
        
        # Release keys that are no longer needed
        keys_to_release = self.current_keys - target_keys
        for key in keys_to_release:
            try:
                self.keyboard.release(key)
                print(f"Released key: {key}")
            except Exception as e:
                print(f"Error releasing key {key}: {e}")
        
        # Press keys that are needed but not currently pressed
        keys_to_press = target_keys - self.current_keys
        for key in keys_to_press:
            try:
                self.keyboard.press(key)
                print(f"Pressed key: {key}")
                time.sleep(0.01)
            except Exception as e:
                print(f"Error pressing key {key}: {e}")
        
        # Update current keys
        self.current_keys = target_keys
        self.last_key_time = current_time
    
    def draw_debug_overlay(self, frame: np.ndarray, left_gesture: str, 
                          right_gesture: str) -> np.ndarray:
        """
        Draw debug overlay on the frame for shooting game.
        
        Args:
            frame: Input frame
            left_gesture: Left hand gesture detected
            right_gesture: Right hand gesture detected
            
        Returns:
            Frame with debug overlay
        """
        h, w = frame.shape[:2]
        
        # Draw gesture information
        cv2.putText(frame, f"Left Hand: {left_gesture or 'None'}", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.putText(frame, f"Right Hand: {right_gesture or 'None'}", (10, 60), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        # Draw control mappings
        cv2.putText(frame, "LEFT HAND CONTROLS:", (10, h - 120), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(frame, "Open Palm = Move Forward (W)", (10, h - 100), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(frame, "Fist = Move Backward (S)", (10, h - 80), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        cv2.putText(frame, "RIGHT HAND CONTROLS:", (w - 300, h - 120), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(frame, "Open Palm = Aim Down Sights", (w - 300, h - 100), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(frame, "Fist = Reload (R)", (w - 300, h - 80), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        cv2.putText(frame, "Press 'q' to quit", (10, h - 10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        return frame
    
    def run(self):
        """Main application loop for shooting game."""
        print("Shooting Game Gesture Controller")
        print("===============================")
        print("Gesture Mapping:")
        print("LEFT HAND:")
        print("- Open Palm: Move Forward (W)")
        print("- Fist: Move Backward (S)")
        print("RIGHT HAND:")
        print("- Open Palm: Aim Down Sights (Right Mouse Button)")
        print("- Fist: Reload (R)")
        print("Press 'q' to quit the application")
        print()
        
        if not self.initialize_camera():
            return
        
        self.running = True
        
        try:
            while self.running:
                ret, frame = self.cap.read()
                if not ret:
                    print("Error: Could not read frame from camera")
                    break
                
                # Flip frame horizontally for mirror effect
                frame = cv2.flip(frame, 1)
                
                # Detect hand gestures
                left_gesture, right_gesture, annotated_frame = self.detect_hand_gestures(frame)
                
                # Handle the gestures
                self.handle_gestures(left_gesture, right_gesture)
                
                # Draw debug overlay
                debug_frame = self.draw_debug_overlay(
                    annotated_frame, left_gesture, right_gesture
                )
                
                # Display the frame
                cv2.imshow('Shooting Game Gesture Controller', debug_frame)
                
                # Check for quit command
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    self.running = False
                elif key == ord('r'):
                    # Reset all keys
                    self.release_all_keys()
                    print("Reset: All keys released")
        
        except KeyboardInterrupt:
            print("\nApplication interrupted by user")
        
        finally:
            self.cleanup()
    
    def release_all_keys(self):
        """Release all currently pressed keys."""
        for key in self.current_keys.copy():
            try:
                self.keyboard.release(key)
                print(f"Released key: {key}")
            except Exception as e:
                print(f"Error releasing key {key}: {e}")
        
        self.current_keys.clear()
    
    def cleanup(self):
        """Clean up resources."""
        print("Cleaning up...")
        
        self.release_all_keys()
        
        if self.cap:
            self.cap.release()
        
        cv2.destroyAllWindows()
        print("Cleanup complete")

def main():
    """Main entry point for shooting game mode."""
    app = ShootingGestureController()
    app.run()

if __name__ == "__main__":
    main()
