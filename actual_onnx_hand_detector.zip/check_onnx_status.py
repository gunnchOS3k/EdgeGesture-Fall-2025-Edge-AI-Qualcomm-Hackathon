#!/usr/bin/env python3
"""
Check ONNX model usage status across all components
"""

import sys
import os
import importlib

def check_onnx_usage():
    """Check which models are actually being used."""
    print("🔍 ONNX Model Usage Status Check")
    print("=" * 50)
    
    # Check hand detector
    print("\n1. Hand Detector Status:")
    try:
        from optimized_hand_detector import OptimizedHandDetector
        detector = OptimizedHandDetector(use_onnx=True)
        stats = detector.get_performance_stats()
        print(f"   ✅ Optimized Hand Detector loaded")
        print(f"   📊 Model Type: {stats.get('model_type', 'Unknown')}")
        print(f"   🚀 Using ONNX: {stats.get('use_onnx', False)}")
        detector.cleanup()
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Check real ONNX hand detector
    print("\n2. Real ONNX Hand Detector Status:")
    try:
        from real_onnx_hand_detector import RealONNXHandDetector
        detector = RealONNXHandDetector(use_onnx=True)
        stats = detector.get_performance_stats()
        print(f"   ✅ Real ONNX Hand Detector loaded")
        print(f"   📊 Model Type: {stats.get('model_type', 'Unknown')}")
        print(f"   🚀 Using ONNX: {stats.get('use_onnx', False)}")
        detector.cleanup()
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Check Whisper transcriber
    print("\n3. Whisper Transcriber Status:")
    try:
        from onnx_whisper_transcriber import ONNXWhisperTranscriber
        transcriber = ONNXWhisperTranscriber()
        info = transcriber.get_debug_info()
        print(f"   ✅ ONNX Whisper Transcriber loaded")
        print(f"   📊 Model Type: {info.get('model_type', 'Unknown')}")
        print(f"   🚀 Using ONNX: {not info.get('use_whisper', True)}")
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Check real ONNX Whisper
    print("\n4. Real ONNX Whisper Status:")
    try:
        from real_onnx_whisper import RealONNXWhisperTranscriber
        transcriber = RealONNXWhisperTranscriber()
        info = transcriber.get_debug_info()
        print(f"   ✅ Real ONNX Whisper loaded")
        print(f"   📊 Model Type: {info.get('model_type', 'Unknown')}")
        print(f"   🚀 Using ONNX: {not info.get('use_whisper', True)}")
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Check ONNX runtime availability
    print("\n5. ONNX Runtime Status:")
    try:
        import onnxruntime as ort
        print(f"   ✅ ONNX Runtime available")
        print(f"   📊 Version: {ort.__version__}")
        
        # Check available providers
        providers = ort.get_available_providers()
        print(f"   🚀 Available Providers: {providers}")
        
        if 'CUDAExecutionProvider' in providers:
            print(f"   🎮 GPU acceleration available!")
        else:
            print(f"   💻 CPU-only execution")
            
    except Exception as e:
        print(f"   ❌ ONNX Runtime not available: {e}")
    
    # Check MediaPipe status
    print("\n6. MediaPipe Status:")
    try:
        import mediapipe as mp
        print(f"   ✅ MediaPipe available")
        print(f"   📊 Version: {mp.__version__}")
    except Exception as e:
        print(f"   ❌ MediaPipe not available: {e}")
    
    # Check Whisper status
    print("\n7. Whisper Status:")
    try:
        import whisper
        print(f"   ✅ Whisper available")
        print(f"   📊 Version: {whisper.__version__}")
    except Exception as e:
        print(f"   ❌ Whisper not available: {e}")
    
    print("\n" + "=" * 50)
    print("📋 Summary:")
    print("   • Hand Detection: Currently using MediaPipe (not ONNX)")
    print("   • Whisper: Currently using original Whisper (not ONNX)")
    print("   • ONNX Runtime: Available but not actively used")
    print("   • Reason: Mock implementations fall back to original models")
    print("\n💡 To use real ONNX models:")
    print("   1. Download actual MediaPipe ONNX models")
    print("   2. Download actual Whisper ONNX models")
    print("   3. Update the implementations to load real ONNX files")

if __name__ == "__main__":
    check_onnx_usage()
