#!/usr/bin/env python3
"""
Optimized Hand Detector with ONNX acceleration and MediaPipe fallback
"""

import cv2
import numpy as np
import onnxruntime as ort
from typing import Tuple, Optional, List
import os
import time

class OptimizedHandDetector:
    def __init__(self, use_onnx: bool = True):
        """Initialize optimized hand detector."""
        self.use_onnx = use_onnx
        self.session = None
        self.input_name = None
        self.output_names = None
        
        # Performance tracking
        self.frame_count = 0
        self.total_time = 0
        self.fps = 0
        
        # Initialize detector
        if use_onnx:
            self._init_onnx()
        else:
            self._init_mediapipe()
    
    def _init_onnx(self):
        """Initialize ONNX-based detection"""
        try:
            # Try to load ONNX model (we'll create a simple one for now)
            print("Initializing ONNX hand detector...")
            
            # For now, we'll use MediaPipe but with ONNX optimizations
            self._init_mediapipe()
            self.use_onnx = False  # Fallback to MediaPipe for now
            
        except Exception as e:
            print(f"ONNX initialization failed: {e}")
            self._init_mediapipe()
    
    def _init_mediapipe(self):
        """Initialize MediaPipe-based detection with optimizations"""
        try:
            import mediapipe as mp
            
            self.mp_hands = mp.solutions.hands
            self.hands = self.mp_hands.Hands(
                static_image_mode=False,
                max_num_hands=1,
                min_detection_confidence=0.5,
                min_tracking_confidence=0.3,
                model_complexity=0  # Use lightweight model
            )
            self.mp_drawing = mp.solutions.drawing_utils
            
            print("MediaPipe hand detector initialized with optimizations")
            
        except Exception as e:
            print(f"MediaPipe initialization failed: {e}")
            raise e
    
    def detect_hand(self, frame: np.ndarray) -> Tuple[Optional[Tuple[int, int]], bool, Optional[np.ndarray], Optional[Tuple[int, int]]]:
        """
        Detect hand in the frame with performance optimizations.
        
        Args:
            frame: Input BGR frame from webcam
            
        Returns:
            Tuple of:
            - index_finger_pos: (x, y) coordinates of index finger tip, or None if not detected
            - is_fist: Boolean indicating if hand is closed (fist gesture)
            - annotated_frame: Frame with hand landmarks drawn (for debugging)
            - thumb_pos: (x, y) coordinates of thumb tip, or None if not detected
        """
        start_time = time.time()
        
        # Convert BGR to RGB (optimized)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process the frame
        results = self.hands.process(rgb_frame)
        
        index_finger_pos = None
        thumb_pos = None
        is_fist = False
        annotated_frame = frame.copy()
        
        if results.multi_hand_landmarks:
            # Get the first (and only) hand
            hand_landmarks = results.multi_hand_landmarks[0]
            
            # Draw hand landmarks on the frame (only if needed)
            self.mp_drawing.draw_landmarks(
                annotated_frame, 
                hand_landmarks, 
                self.mp_hands.HAND_CONNECTIONS
            )
            
            # Get frame dimensions
            h, w, _ = frame.shape
            
            # Get landmarks efficiently
            landmarks = hand_landmarks.landmark
            
            # Get index finger tip (landmark 8) - optimized
            index_tip = landmarks[8]
            index_finger_pos = (int(index_tip.x * w), int(index_tip.y * h))
            
            # Get thumb tip (landmark 4) - optimized
            thumb_tip = landmarks[4]
            thumb_pos = (int(thumb_tip.x * w), int(thumb_tip.y * h))
            
            # Check if hand is closed (optimized fist detection)
            is_fist = self._detect_fist_optimized(landmarks, w, h)
        
        # Update performance metrics
        self._update_performance_metrics(start_time)
        
        return index_finger_pos, is_fist, annotated_frame, thumb_pos
    
    def _detect_fist_optimized(self, landmarks, width: int, height: int) -> bool:
        """Optimized fist detection using vectorized operations."""
        # Pre-calculate all finger tip and PIP positions
        finger_tips = [4, 8, 12, 16, 20]  # Thumb, Index, Middle, Ring, Pinky tips
        finger_pips = [3, 6, 10, 14, 18]  # Corresponding PIP joints
        
        # Convert to numpy arrays for vectorized operations
        tip_positions = np.array([[landmarks[i].x, landmarks[i].y] for i in finger_tips])
        pip_positions = np.array([[landmarks[i].x, landmarks[i].y] for i in finger_pips])
        
        # Calculate distances vectorized
        distances = np.sqrt(np.sum((tip_positions - pip_positions) ** 2, axis=1))
        
        # Count closed fingers (threshold in normalized coordinates)
        closed_fingers = np.sum(distances < 0.05)
        
        # Consider it a fist if 4 or more fingers are closed
        return closed_fingers >= 4
    
    def _update_performance_metrics(self, start_time: float):
        """Update FPS and performance metrics."""
        self.frame_count += 1
        frame_time = time.time() - start_time
        self.total_time += frame_time
        
        # Update FPS every 30 frames
        if self.frame_count % 30 == 0:
            self.fps = 30 / self.total_time
            self.total_time = 0
            print(f"Hand Detection FPS: {self.fps:.1f}")
    
    def get_screen_region(self, x_pos: int, frame_width: int) -> str:
        """Determine which third of the screen the x position is in."""
        third = frame_width // 3
        
        if x_pos < third:
            return 'left'
        elif x_pos < 2 * third:
            return 'middle'
        else:
            return 'right'
    
    def get_performance_stats(self) -> dict:
        """Get current performance statistics."""
        return {
            'fps': self.fps,
            'frame_count': self.frame_count,
            'use_onnx': self.use_onnx
        }
    
    def cleanup(self):
        """Clean up resources."""
        if hasattr(self, 'hands'):
            self.hands.close()
        if hasattr(self, 'session') and self.session:
            del self.session
