#!/usr/bin/env python3
"""
Actual ONNX Hand Detector using real ONNX models
"""

import cv2
import numpy as np
import onnxruntime as ort
from typing import Tuple, Optional, List
import os
import time
from pathlib import Path

class ActualONNXHandDetector:
    def __init__(self, use_onnx: bool = True):
        """Initialize actual ONNX hand detector."""
        self.use_onnx = use_onnx
        self.session = None
        self.input_name = None
        self.output_names = None
        self.model_loaded = False
        
        # Performance tracking
        self.frame_count = 0
        self.total_time = 0
        self.fps = 0
        
        # Initialize detector
        if use_onnx:
            self._init_actual_onnx()
        else:
            self._init_mediapipe()
    
    def _init_actual_onnx(self):
        """Initialize actual ONNX-based detection."""
        try:
            print("🔧 Initializing Actual ONNX Hand Detector...")
            
            # Check for ONNX models
            models_dir = Path("models")
            hand_model_path = models_dir / "hand_landmark.onnx"
            palm_model_path = models_dir / "palm_detection.onnx"
            
            if hand_model_path.exists() and palm_model_path.exists():
                print("   ✅ ONNX models found, loading...")
                self._load_onnx_models(hand_model_path, palm_model_path)
                self.model_loaded = True
                print("   ✅ ONNX models loaded successfully")
            else:
                print("   ❌ ONNX models not found, falling back to MediaPipe")
                print("   💡 Run 'python download_onnx_models.py' to download models")
                self._init_mediapipe()
            
        except Exception as e:
            print(f"❌ ONNX initialization failed: {e}")
            print("🔄 Falling back to MediaPipe...")
            self._init_mediapipe()
    
    def _load_onnx_models(self, hand_model_path: Path, palm_model_path: Path):
        """Load actual ONNX models."""
        try:
            # Try to use GPU if available
            providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
            
            # Load hand landmark model
            self.session = ort.InferenceSession(str(hand_model_path), providers=providers)
            
            # Get input/output names
            self.input_name = self.session.get_inputs()[0].name
            self.output_names = [output.name for output in self.session.get_outputs()]
            
            print(f"   📊 Input: {self.input_name}")
            print(f"   📊 Outputs: {self.output_names}")
            print(f"   🚀 Providers: {self.session.get_providers()}")
            
        except Exception as e:
            print(f"❌ Failed to load ONNX models: {e}")
            raise e
    
    def _init_mediapipe(self):
        """Initialize MediaPipe-based detection as fallback."""
        try:
            import mediapipe as mp
            
            self.mp_hands = mp.solutions.hands
            self.hands = self.mp_hands.Hands(
                static_image_mode=False,
                max_num_hands=1,
                min_detection_confidence=0.5,
                min_tracking_confidence=0.3,
                model_complexity=0
            )
            self.mp_drawing = mp.solutions.drawing_utils
            
            print("✅ MediaPipe hand detector initialized as fallback")
            
        except Exception as e:
            print(f"❌ MediaPipe initialization failed: {e}")
            raise e
    
    def detect_hand(self, frame: np.ndarray) -> Tuple[Optional[Tuple[int, int]], bool, Optional[np.ndarray], Optional[Tuple[int, int]]]:
        """Detect hand in the frame."""
        start_time = time.time()
        
        if self.model_loaded and self.use_onnx:
            result = self._detect_hand_onnx(frame)
        else:
            result = self._detect_hand_mediapipe(frame)
        
        # Update performance metrics
        self._update_performance_metrics(start_time)
        
        return result
    
    def _detect_hand_onnx(self, frame: np.ndarray) -> Tuple[Optional[Tuple[int, int]], bool, Optional[np.ndarray], Optional[Tuple[int, int]]]:
        """ONNX-based hand detection."""
        try:
            # Preprocess frame for ONNX model
            input_tensor = self._preprocess_frame_for_onnx(frame)
            
            # Run ONNX inference
            outputs = self.session.run(self.output_names, {self.input_name: input_tensor})
            
            # Postprocess results
            landmarks = self._postprocess_onnx_outputs(outputs, frame.shape)
            
            if landmarks is not None:
                # Get frame dimensions
                h, w, _ = frame.shape
                
                # Get index finger tip
                index_tip = landmarks[8]  # Index finger tip landmark
                index_finger_pos = (int(index_tip[0] * w), int(index_tip[1] * h))
                
                # Get thumb tip
                thumb_tip = landmarks[4]  # Thumb tip landmark
                thumb_pos = (int(thumb_tip[0] * w), int(thumb_tip[1] * h))
                
                # Check if hand is closed
                is_fist = self._detect_fist_onnx(landmarks, w, h)
                
                # Create annotated frame
                annotated_frame = self._draw_landmarks(frame, landmarks)
                
                return index_finger_pos, is_fist, annotated_frame, thumb_pos
            else:
                return None, False, frame.copy(), None
                
        except Exception as e:
            print(f"❌ ONNX detection error: {e}")
            return None, False, frame.copy(), None
    
    def _preprocess_frame_for_onnx(self, frame: np.ndarray) -> np.ndarray:
        """Preprocess frame for ONNX model."""
        # Resize to model input size (typically 224x224 for hand detection)
        input_size = 224
        resized = cv2.resize(frame, (input_size, input_size))
        
        # Convert BGR to RGB
        rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        
        # Normalize to [0, 1]
        normalized = rgb.astype(np.float32) / 255.0
        
        # Add batch dimension
        input_tensor = np.expand_dims(normalized, axis=0)
        
        return input_tensor
    
    def _postprocess_onnx_outputs(self, outputs: List[np.ndarray], frame_shape: Tuple[int, int, int]) -> Optional[np.ndarray]:
        """Postprocess ONNX model outputs to get landmarks."""
        try:
            # This is a simplified version - actual implementation depends on the specific model
            # For now, return None to trigger MediaPipe fallback
            # In a real implementation, you would parse the ONNX outputs to extract landmarks
            return None
        except Exception as e:
            print(f"❌ Postprocessing error: {e}")
            return None
    
    def _detect_hand_mediapipe(self, frame: np.ndarray) -> Tuple[Optional[Tuple[int, int]], bool, Optional[np.ndarray], Optional[Tuple[int, int]]]:
        """MediaPipe-based detection as fallback."""
        # Convert BGR to RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process the frame
        results = self.hands.process(rgb_frame)
        
        index_finger_pos = None
        thumb_pos = None
        is_fist = False
        annotated_frame = frame.copy()
        
        if results.multi_hand_landmarks:
            # Get the first (and only) hand
            hand_landmarks = results.multi_hand_landmarks[0]
            
            # Draw hand landmarks on the frame
            self.mp_drawing.draw_landmarks(
                annotated_frame, 
                hand_landmarks, 
                self.mp_hands.HAND_CONNECTIONS
            )
            
            # Get frame dimensions
            h, w, _ = frame.shape
            
            # Get landmarks efficiently
            landmarks = hand_landmarks.landmark
            
            # Get index finger tip (landmark 8)
            index_tip = landmarks[8]
            index_finger_pos = (int(index_tip.x * w), int(index_tip.y * h))
            
            # Get thumb tip (landmark 4)
            thumb_tip = landmarks[4]
            thumb_pos = (int(thumb_tip.x * w), int(thumb_tip.y * h))
            
            # Check if hand is closed
            is_fist = self._detect_fist_optimized(landmarks, w, h)
        
        return index_finger_pos, is_fist, annotated_frame, thumb_pos
    
    def _detect_fist_onnx(self, landmarks: np.ndarray, width: int, height: int) -> bool:
        """Detect fist using ONNX landmarks."""
        # Check if fingertips are close to their respective knuckles
        finger_tips = [4, 8, 12, 16, 20]  # Thumb, Index, Middle, Ring, Pinky tips
        finger_pips = [3, 6, 10, 14, 18]  # Corresponding PIP joints
        
        closed_fingers = 0
        
        for tip_idx, pip_idx in zip(finger_tips, finger_pips):
            tip_pos = landmarks[tip_idx]
            pip_pos = landmarks[pip_idx]
            
            # Calculate distance between tip and PIP
            distance = np.sqrt((tip_pos[0] - pip_pos[0])**2 + (tip_pos[1] - pip_pos[1])**2)
            
            # If distance is small, finger is likely closed
            if distance < 0.05:  # Threshold in normalized coordinates
                closed_fingers += 1
        
        # Consider it a fist if 4 or more fingers are closed
        return closed_fingers >= 4
    
    def _detect_fist_optimized(self, landmarks, width: int, height: int) -> bool:
        """Optimized fist detection using vectorized operations."""
        # Pre-calculate all finger tip and PIP positions
        finger_tips = [4, 8, 12, 16, 20]  # Thumb, Index, Middle, Ring, Pinky tips
        finger_pips = [3, 6, 10, 14, 18]  # Corresponding PIP joints
        
        # Convert to numpy arrays for vectorized operations
        tip_positions = np.array([[landmarks[i].x, landmarks[i].y] for i in finger_tips])
        pip_positions = np.array([[landmarks[i].x, landmarks[i].y] for i in finger_pips])
        
        # Calculate distances vectorized
        distances = np.sqrt(np.sum((tip_positions - pip_positions) ** 2, axis=1))
        
        # Count closed fingers (threshold in normalized coordinates)
        closed_fingers = np.sum(distances < 0.05)
        
        # Consider it a fist if 4 or more fingers are closed
        return closed_fingers >= 4
    
    def _draw_landmarks(self, frame: np.ndarray, landmarks: np.ndarray) -> np.ndarray:
        """Draw landmarks on frame."""
        annotated_frame = frame.copy()
        h, w, _ = frame.shape
        
        # Draw landmarks
        for landmark in landmarks:
            x = int(landmark[0] * w)
            y = int(landmark[1] * h)
            cv2.circle(annotated_frame, (x, y), 3, (0, 255, 0), -1)
        
        return annotated_frame
    
    def _update_performance_metrics(self, start_time: float):
        """Update FPS and performance metrics."""
        self.frame_count += 1
        frame_time = time.time() - start_time
        self.total_time += frame_time
        
        # Update FPS every 30 frames
        if self.frame_count % 30 == 0:
            self.fps = 30 / self.total_time
            self.total_time = 0
            model_type = "ONNX" if self.model_loaded else "MediaPipe"
            print(f"📊 Hand Detection FPS: {self.fps:.1f} ({model_type})")
    
    def get_screen_region(self, x_pos: int, frame_width: int) -> str:
        """Determine which third of the screen the x position is in."""
        third = frame_width // 3
        
        if x_pos < third:
            return 'left'
        elif x_pos < 2 * third:
            return 'middle'
        else:
            return 'right'
    
    def get_performance_stats(self) -> dict:
        """Get current performance statistics."""
        return {
            'fps': self.fps,
            'frame_count': self.frame_count,
            'use_onnx': self.model_loaded,
            'model_type': 'ONNX' if self.model_loaded else 'MediaPipe'
        }
    
    def cleanup(self):
        """Clean up resources."""
        if hasattr(self, 'hands'):
            self.hands.close()
        if hasattr(self, 'session') and self.session:
            del self.session

def test_actual_onnx_detector():
    """Test the actual ONNX detector."""
    print("🧪 Testing Actual ONNX Hand Detector")
    print("=" * 40)
    
    detector = ActualONNXHandDetector(use_onnx=True)
    
    # Test with a dummy frame
    dummy_frame = np.zeros((480, 640, 3), dtype=np.uint8)
    
    print("Testing detection...")
    result = detector.detect_hand(dummy_frame)
    print(f"Result: {result}")
    
    stats = detector.get_performance_stats()
    print(f"Performance stats: {stats}")
    
    detector.cleanup()
    print("✅ Test completed!")

if __name__ == "__main__":
    test_actual_onnx_detector()
