#!/usr/bin/env python3
"""
Performance comparison between original and optimized hand detectors
"""

import cv2
import time
import numpy as np
from hand_detector import HandDetector
from optimized_hand_detector import OptimizedHandDetector

def test_performance():
    """Test performance of both hand detectors"""
    print("🚀 Hand Detection Performance Test")
    print("=" * 50)
    
    # Initialize detectors
    print("Initializing detectors...")
    original_detector = HandDetector()
    optimized_detector = OptimizedHandDetector(use_onnx=True)
    
    # Initialize camera
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("❌ Could not open camera")
        return
    
    # Set camera properties for better performance
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, 60)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    
    print("✅ Camera initialized")
    print("\nTesting original MediaPipe detector...")
    
    # Test original detector
    original_times = []
    frame_count = 0
    max_frames = 100
    
    start_time = time.time()
    
    while frame_count < max_frames:
        ret, frame = cap.read()
        if not ret:
            break
        
        frame_start = time.time()
        index_pos, is_fist, annotated_frame, thumb_pos = original_detector.detect_hand(frame)
        frame_time = time.time() - frame_start
        
        original_times.append(frame_time)
        frame_count += 1
        
        # Show progress
        if frame_count % 20 == 0:
            print(f"  Processed {frame_count}/{max_frames} frames")
    
    original_total_time = time.time() - start_time
    original_avg_fps = max_frames / original_total_time
    original_avg_time = np.mean(original_times) * 1000  # Convert to ms
    
    print(f"✅ Original detector results:")
    print(f"   Average FPS: {original_avg_fps:.1f}")
    print(f"   Average frame time: {original_avg_time:.1f}ms")
    print(f"   Total time: {original_total_time:.2f}s")
    
    print("\nTesting optimized detector...")
    
    # Test optimized detector
    optimized_times = []
    frame_count = 0
    
    start_time = time.time()
    
    while frame_count < max_frames:
        ret, frame = cap.read()
        if not ret:
            break
        
        frame_start = time.time()
        index_pos, is_fist, annotated_frame, thumb_pos = optimized_detector.detect_hand(frame)
        frame_time = time.time() - frame_start
        
        optimized_times.append(frame_time)
        frame_count += 1
        
        # Show progress
        if frame_count % 20 == 0:
            print(f"  Processed {frame_count}/{max_frames} frames")
    
    optimized_total_time = time.time() - start_time
    optimized_avg_fps = max_frames / optimized_total_time
    optimized_avg_time = np.mean(optimized_times) * 1000  # Convert to ms
    
    print(f"✅ Optimized detector results:")
    print(f"   Average FPS: {optimized_avg_fps:.1f}")
    print(f"   Average frame time: {optimized_avg_time:.1f}ms")
    print(f"   Total time: {optimized_total_time:.2f}s")
    
    # Calculate improvements
    fps_improvement = ((optimized_avg_fps - original_avg_fps) / original_avg_fps) * 100
    time_improvement = ((original_avg_time - optimized_avg_time) / original_avg_time) * 100
    
    print(f"\n📊 Performance Comparison:")
    print(f"   FPS improvement: {fps_improvement:+.1f}%")
    print(f"   Time reduction: {time_improvement:+.1f}%")
    
    if fps_improvement > 0:
        print(f"   🚀 Optimized detector is {fps_improvement:.1f}% faster!")
    else:
        print(f"   ⚠️  Original detector is {abs(fps_improvement):.1f}% faster")
    
    # Cleanup
    cap.release()
    cv2.destroyAllWindows()
    
    print("\n✅ Performance test completed!")

if __name__ == "__main__":
    test_performance()
