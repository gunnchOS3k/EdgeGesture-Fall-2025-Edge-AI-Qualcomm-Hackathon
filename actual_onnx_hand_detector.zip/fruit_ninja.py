#!/usr/bin/env python3
"""
Fruit Ninja Game Gesture Controller Module.
Handles gesture-to-mouse mapping for Fruit Ninja style slicing game.
"""

import cv2
import numpy as np
import sys
import time
import os
import webbrowser
import pyautogui
from hand_detector import HandDetector
from pynput.mouse import Button, Controller as MouseController

class FruitNinjaGestureController:
    def __init__(self):
        """Initialize the Fruit Ninja gesture controller."""
        self.hand_detector = HandDetector()
        self.mouse = MouseController()
        self.cap = None
        self.running = False
        
        # Mouse control state
        self.mouse_pressed = False
        self.last_finger_pos = None
        self.mouse_sensitivity = 0.8  # Adjust this to change mouse sensitivity
        self.center_x = 320  # Center of camera frame
        self.center_y = 240  # Center of camera frame
        
        # Get screen dimensions
        self.screen_width, self.screen_height = pyautogui.size()
        
        # Small delay to prevent too rapid operations
        self.last_operation_time = 0
        self.last_click_time = 0
        self.operation_delay = 0.01  # 10ms delay between operations
        self.click_delay = 0.1  # 100ms delay between clicks for slicing
        
    def initialize_camera(self) -> bool:
        """Initialize the webcam."""
        try:
            self.cap = cv2.VideoCapture(0)
            if not self.cap.isOpened():
                print("Error: Could not open webcam")
                return False
            
            # Set camera properties for better performance
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self.cap.set(cv2.CAP_PROP_FPS, 30)
            
            print("Camera initialized successfully")
            return True
        except Exception as e:
            print(f"Error initializing camera: {e}")
            return False
    
    def open_fruit_ninja_game(self):
        """Open a Fruit Ninja style game in browser."""
        print("Opening Fruit Ninja style game...")
        
        # Create a simple HTML5 Fruit Ninja game
        fruit_ninja_html = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fruit Ninja - Gesture Controlled</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-family: Arial, sans-serif;
            overflow: hidden;
        }
        
        #gameCanvas {
            display: block;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            cursor: crosshair;
        }
        
        .score {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 24px;
            z-index: 10;
        }
        
        .instructions {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 16px;
            text-align: right;
            z-index: 10;
        }
        
        .game-over {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 48px;
            text-align: center;
            z-index: 20;
            display: none;
        }
    </style>
</head>
<body>
    <div class="score">Score: <span id="score">0</span></div>
    <div class="instructions">
        Use pinch gesture to slice fruits!<br>
        Don't let them fall!
    </div>
    <canvas id="gameCanvas" width="800" height="600"></canvas>
    <div class="game-over" id="gameOver">
        Game Over!<br>
        <span id="finalScore">0</span> points<br>
        <button onclick="restartGame()">Play Again</button>
    </div>

    <script>
        const canvas = document.getElementById('gameCanvas');
        const ctx = canvas.getContext('2d');
        
        let score = 0;
        let gameRunning = true;
        let fruits = [];
        let slices = [];
        let lastSliceTime = 0;
        
        // Fruit class
        class Fruit {
            constructor() {
                this.x = Math.random() * canvas.width;
                this.y = canvas.height + 50;
                this.vx = (Math.random() - 0.5) * 4;
                this.vy = -Math.random() * 8 - 3;
                this.radius = 20 + Math.random() * 20;
                this.color = `hsl(${Math.random() * 360}, 70%, 60%)`;
                this.rotation = 0;
                this.rotationSpeed = (Math.random() - 0.5) * 0.2;
            }
            
            update() {
                this.x += this.vx;
                this.y += this.vy;
                this.vy += 0.3; // gravity
                this.rotation += this.rotationSpeed;
            }
            
            draw() {
                ctx.save();
                ctx.translate(this.x, this.y);
                ctx.rotate(this.rotation);
                ctx.fillStyle = this.color;
                ctx.beginPath();
                ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
            }
            
            isOffScreen() {
                return this.y > canvas.height + 50 || this.x < -50 || this.x > canvas.width + 50;
            }
        }
        
        // Slice class
        class Slice {
            constructor(x, y) {
                this.x = x;
                this.y = y;
                this.life = 30;
                this.maxLife = 30;
            }
            
            update() {
                this.life--;
            }
            
            draw() {
                const alpha = this.life / this.maxLife;
                ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.arc(this.x, this.y, 30, 0, Math.PI * 2);
                ctx.stroke();
            }
            
            isDead() {
                return this.life <= 0;
            }
        }
        
        // Game functions
        function spawnFruit() {
            if (Math.random() < 0.02) {
                fruits.push(new Fruit());
            }
        }
        
        function updateFruits() {
            for (let i = fruits.length - 1; i >= 0; i--) {
                const fruit = fruits[i];
                fruit.update();
                
                if (fruit.isOffScreen()) {
                    fruits.splice(i, 1);
                    if (gameRunning) {
                        score = Math.max(0, score - 10);
                    }
                }
            }
        }
        
        function updateSlices() {
            for (let i = slices.length - 1; i >= 0; i--) {
                const slice = slices[i];
                slice.update();
                
                if (slice.isDead()) {
                    slices.splice(i, 1);
                }
            }
        }
        
        function checkCollisions() {
            for (let i = fruits.length - 1; i >= 0; i--) {
                const fruit = fruits[i];
                
                for (let j = slices.length - 1; j >= 0; j--) {
                    const slice = slices[j];
                    const dx = fruit.x - slice.x;
                    const dy = fruit.y - slice.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance < fruit.radius + 30) {
                        // Fruit sliced!
                        fruits.splice(i, 1);
                        slices.splice(j, 1);
                        score += 10;
                        break;
                    }
                }
            }
        }
        
        function draw() {
            // Clear canvas
            ctx.fillStyle = 'rgba(102, 126, 234, 0.1)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // Draw fruits
            fruits.forEach(fruit => fruit.draw());
            
            // Draw slices
            slices.forEach(slice => slice.draw());
            
            // Draw score
            ctx.fillStyle = 'white';
            ctx.font = '24px Arial';
            ctx.fillText(`Score: ${score}`, 20, 40);
        }
        
        function gameLoop() {
            if (gameRunning) {
                spawnFruit();
                updateFruits();
                updateSlices();
                checkCollisions();
            }
            
            draw();
            requestAnimationFrame(gameLoop);
        }
        
        function sliceFruit(x, y) {
            const currentTime = Date.now();
            if (currentTime - lastSliceTime > 100) { // 100ms delay between slices
                slices.push(new Slice(x, y));
                lastSliceTime = currentTime;
            }
        }
        
        function restartGame() {
            score = 0;
            fruits = [];
            slices = [];
            gameRunning = true;
            document.getElementById('gameOver').style.display = 'none';
        }
        
        // Mouse events for slicing
        canvas.addEventListener('mousedown', (e) => {
            const rect = canvas.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            sliceFruit(x, y);
        });
        
        // Start the game
        gameLoop();
        
        // Spawn fruits periodically
        setInterval(() => {
            if (gameRunning && fruits.length < 5) {
                fruits.push(new Fruit());
            }
        }, 2000);
    </script>
</body>
</html>
"""
        
        # Write the HTML file
        with open("fruit_ninja_game.html", "w") as f:
            f.write(fruit_ninja_html)
        
        # Open in browser
        fruit_file = os.path.abspath("fruit_ninja_game.html")
        webbrowser.open(f"file://{fruit_file}")
        print("✓ Fruit Ninja game opened in browser")
        
        # Give the browser a moment to load and get focus
        print("Waiting for game to load and get focus...")
        time.sleep(3)
        
        # Try to focus the browser window
        try:
            # Click on the browser window to ensure it has focus
            pyautogui.click(400, 300)  # Click in the center of a typical browser window
            time.sleep(0.5)
            print("✓ Browser window focused")
        except Exception as e:
            print(f"Could not focus browser window: {e}")
            print("Please click on the browser window to give it focus")
        
        print("\nIMPORTANT: Make sure the browser window with the Fruit Ninja game is in focus!")
        print("Click on the browser window if needed before the gesture controller starts.")
    
    def detect_pinch_gesture(self, frame):
        """Detect pinch gesture for slicing."""
        # Detect hand and get gesture information
        index_finger_pos, is_fist, annotated_frame, thumb_pos = self.hand_detector.detect_hand(frame)
        
        gesture_type = None
        middle_pos = None
        
        if index_finger_pos and thumb_pos:
            # Calculate middle point between thumb and index finger
            middle_pos = (
                (index_finger_pos[0] + thumb_pos[0]) // 2,
                (index_finger_pos[1] + thumb_pos[1]) // 2
            )
            
            # Check if thumb and index finger are pinching (close together)
            distance = ((index_finger_pos[0] - thumb_pos[0])**2 + (index_finger_pos[1] - thumb_pos[1])**2)**0.5
            if distance < 25:  # Threshold for "pinching" (tighter than touch)
                gesture_type = 'pinch'  # Slice
            else:
                gesture_type = 'pointing'  # Just move mouse
        elif index_finger_pos:
            # Fallback to index finger only if thumb not detected
            middle_pos = index_finger_pos
            gesture_type = 'pointing'
        else:
            gesture_type = 'none'  # No hand detected
        
        # Store distance for debugging
        if index_finger_pos and thumb_pos:
            self.last_distance = distance
        
        return gesture_type, middle_pos, annotated_frame, thumb_pos
    
    def handle_gestures(self, gesture_type, finger_pos):
        """Handle the detected gestures and control the mouse."""
        current_time = time.time()
        
        # Only process if enough time has passed since last operation
        if current_time - self.last_operation_time < self.operation_delay:
            return
        
        if gesture_type == 'pointing' and finger_pos:
            # Just move mouse - no slicing
            self.move_mouse(finger_pos)
            
        elif gesture_type == 'pinch' and finger_pos:
            # Move mouse and perform slice (click)
            self.move_mouse(finger_pos)
            # Add a delay to prevent too many slices
            if current_time - self.last_click_time > self.click_delay:
                try:
                    self.mouse.click(Button.left, 1)
                    print("Fruit sliced! 🍎")
                    self.last_click_time = current_time
                except Exception as e:
                    print(f"Error slicing: {e}")
            
        elif gesture_type == 'none' or not finger_pos:
            # No hand detected - do nothing
            pass
        
        self.last_operation_time = current_time
    
    def move_mouse(self, finger_pos):
        """Move mouse based on finger position using relative movement."""
        if not finger_pos:
            return
        
        x, y = finger_pos
        
        # Calculate movement relative to center of camera frame
        delta_x = (x - self.center_x) * self.mouse_sensitivity
        delta_y = (y - self.center_y) * self.mouse_sensitivity
        
        # Only move if there's significant movement to avoid jitter
        if abs(delta_x) > 1 or abs(delta_y) > 1:
            try:
                self.mouse.move(delta_x, delta_y)
            except Exception as e:
                print(f"Error moving mouse: {e}")
    
    def draw_debug_overlay(self, frame: np.ndarray, gesture_type: str, 
                          finger_pos: tuple, thumb_pos: tuple = None) -> np.ndarray:
        """
        Draw debug overlay on the frame for Fruit Ninja.
        
        Args:
            frame: Input frame
            gesture_type: Type of gesture detected
            finger_pos: Position of middle point
            thumb_pos: Position of thumb
            
        Returns:
            Frame with debug overlay
        """
        h, w = frame.shape[:2]
        
        # Draw gesture information
        if gesture_type == 'pointing':
            gesture_color = (0, 255, 255)  # Yellow for pointing
        elif gesture_type == 'pinch':
            gesture_color = (0, 255, 0)    # Green for pinch/slice
        elif gesture_type == 'none':
            gesture_color = (128, 128, 128)  # Gray for none
        else:
            gesture_color = (0, 255, 0)    # Green for other
            
        cv2.putText(frame, f"Gesture: {gesture_type.upper()}", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, gesture_color, 2)
        
        # Add pinch detection info
        if gesture_type == 'pinch':
            cv2.putText(frame, "PINCH DETECTED - SLICING!", (10, 90), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        
        # Add distance info for debugging
        if hasattr(self, 'last_distance'):
            cv2.putText(frame, f"Finger distance: {self.last_distance:.1f}px", (10, 120), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            cv2.putText(frame, "Pinch threshold: <25px", (10, 140), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        
        # Draw center point
        cv2.circle(frame, (self.center_x, self.center_y), 5, (0, 255, 255), -1)
        cv2.putText(frame, "CENTER", (self.center_x + 10, self.center_y - 10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 255), 1)
        
        # Draw thumb position
        if thumb_pos:
            tx, ty = thumb_pos
            cv2.circle(frame, (tx, ty), 8, (255, 0, 0), -1)  # Blue circle for thumb
            cv2.putText(frame, "THUMB", (tx + 10, ty - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 0, 0), 1)
        
        # Draw middle point (mouse control point)
        if finger_pos:
            x, y = finger_pos
            cv2.circle(frame, (x, y), 12, (0, 255, 0), -1)  # Green circle for middle point
            cv2.putText(frame, "SLICE", (x + 15, y - 15), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
            
            # Draw line from center to middle point
            cv2.line(frame, (self.center_x, self.center_y), (x, y), (255, 0, 0), 2)
            
            # Draw line between thumb and index finger if both are visible
            if thumb_pos:
                cv2.line(frame, thumb_pos, finger_pos, (255, 255, 0), 2)  # Yellow line
        
        # Draw control instructions
        cv2.putText(frame, "FRUIT NINJA CONTROL:", (10, h - 120), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(frame, "Move hand = Move slice cursor", (10, h - 100), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        cv2.putText(frame, "Pinch fingers = Slice fruit!", (10, h - 80), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        cv2.putText(frame, "No hand = Do nothing", (10, h - 60), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (128, 128, 128), 1)
        
        # Draw sensitivity info
        cv2.putText(frame, f"Sensitivity: {self.mouse_sensitivity:.1f}", (w - 200, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(frame, "Press +/- to adjust", (w - 200, 50), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        
        cv2.putText(frame, "Press 'q' to quit", (10, h - 10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        return frame
    
    def run(self):
        """Main application loop for Fruit Ninja game."""
        print("Fruit Ninja Gesture Controller")
        print("==============================")
        print("Gestures:")
        print("1. Move hand = Move slice cursor")
        print("2. Pinch fingers = Slice fruit!")
        print("3. No hand = Do nothing")
        print()
        print("Visual Guide:")
        print("- Blue circle = Thumb position")
        print("- Green circle = Slice cursor")
        print("- Yellow line = Connection between thumb and index")
        print("- Pinch when fingers are close together to slice!")
        print()
        print("Controls:")
        print("- Press +/- to adjust sensitivity")
        print("- Press 'c' to reset center point")
        print("- Press 'q' to quit")
        print()
        
        # Open the Fruit Ninja game
        self.open_fruit_ninja_game()
        
        if not self.initialize_camera():
            return
        
        self.running = True
        
        try:
            while self.running:
                ret, frame = self.cap.read()
                if not ret:
                    print("Error: Could not read frame from camera")
                    break
                
                # Flip frame horizontally for mirror effect
                frame = cv2.flip(frame, 1)
                
                # Detect pinch gestures
                gesture_type, finger_pos, annotated_frame, thumb_pos = self.detect_pinch_gesture(frame)
                
                # Handle the gestures
                self.handle_gestures(gesture_type, finger_pos)
                
                # Draw debug overlay
                debug_frame = self.draw_debug_overlay(
                    annotated_frame, gesture_type, finger_pos, thumb_pos
                )
                
                # Display the frame
                cv2.imshow('Fruit Ninja Gesture Controller', debug_frame)
                
                # Check for quit command and sensitivity adjustment
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    self.running = False
                elif key == ord('+') or key == ord('='):
                    self.mouse_sensitivity = min(self.mouse_sensitivity + 0.1, 2.0)
                    print(f"Sensitivity increased to {self.mouse_sensitivity:.1f}")
                elif key == ord('-'):
                    self.mouse_sensitivity = max(self.mouse_sensitivity - 0.1, 0.1)
                    print(f"Sensitivity decreased to {self.mouse_sensitivity:.1f}")
                elif key == ord('c'):
                    # Reset center point
                    if finger_pos:
                        self.center_x, self.center_y = finger_pos
                        print(f"Center point reset to ({self.center_x}, {self.center_y})")
        
        except KeyboardInterrupt:
            print("\nApplication interrupted by user")
        
        finally:
            self.cleanup()
    
    def cleanup(self):
        """Clean up resources."""
        print("Cleaning up...")
        
        if self.cap:
            self.cap.release()
        
        cv2.destroyAllWindows()
        print("Cleanup complete")

def main():
    """Main entry point for Fruit Ninja game mode."""
    app = FruitNinjaGestureController()
    app.run()

if __name__ == "__main__":
    main()
