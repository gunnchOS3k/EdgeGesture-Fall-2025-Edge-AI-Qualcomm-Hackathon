#!/usr/bin/env python3
"""
EdgeGesture Application Launcher
Starts the integrated frontend + backend + whisper system
"""

import os
import sys
import subprocess
import time
import webbrowser
import threading
from pathlib import Path

def check_dependencies():
    """Check if required dependencies are installed"""
    print("🔍 Checking dependencies...")
    
    required_packages = [
        'flask', 'flask_cors', 'pynput', 'cv2', 'mediapipe', 
        'numpy', 'sounddevice', 'whisper', 'yaml'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            if package == 'cv2':
                import cv2
            elif package == 'yaml':
                import yaml
            else:
                __import__(package)
            print(f"✅ {package}")
        except ImportError:
            missing_packages.append(package)
            print(f"❌ {package}")
    
    if missing_packages:
        print(f"\n⚠️  Missing packages: {', '.join(missing_packages)}")
        print("📦 Installing missing packages...")
        
        try:
            subprocess.run([
                sys.executable, '-m', 'pip', 'install', '-r', 'requirements_backend.txt'
            ], check=True)
            print("✅ Dependencies installed successfully!")
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to install dependencies: {e}")
            return False
    
    return True

def start_backend():
    """Start the Flask backend server"""
    print("🚀 Starting EdgeGesture Backend Server...")
    
    try:
        # Start the backend server
        backend_process = subprocess.Popen([
            sys.executable, 'backend_server.py'
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Wait a moment for server to start
        time.sleep(3)
        
        # Check if server is running
        if backend_process.poll() is None:
            print("✅ Backend server started successfully!")
            return backend_process
        else:
            stdout, stderr = backend_process.communicate()
            print(f"❌ Backend server failed to start:")
            print(f"STDOUT: {stdout.decode()}")
            print(f"STDERR: {stderr.decode()}")
            return None
            
    except Exception as e:
        print(f"❌ Error starting backend server: {e}")
        return None

def main():
    """Main launcher function"""
    print("=" * 60)
    print("🎮 EdgeGesture - Voice & Hand Control Application")
    print("=" * 60)
    print("Integrating:")
    print("  • React Frontend (Web UI)")
    print("  • Flask Backend (API Server)")
    print("  • Whisper Voice Recognition")
    print("  • MediaPipe Hand Detection")
    print("  • Python Game Modules")
    print("=" * 60)
    
    # Check dependencies
    if not check_dependencies():
        print("❌ Dependency check failed. Please install requirements manually.")
        return
    
    # Start backend server
    backend_process = start_backend()
    if not backend_process:
        print("❌ Failed to start backend server. Exiting.")
        return
    
    print("\n🌐 Application is starting...")
    print("📱 Frontend will open in your browser at: http://localhost:5000")
    print("🎤 Whisper voice recognition will start automatically")
    print("🎮 Use the web interface to start games and configure gestures")
    print("\n💡 Voice Commands:")
    print("  • Say 'start' to begin game actions")
    print("  • Say 'press p' for P key actions")
    print("  • Say 'stop' to pause/stop")
    print("  • Say 'calibrate' to reset center point")
    print("\n⌨️  Press Ctrl+C to stop the application")
    print("=" * 60)
    
    try:
        # Open browser
        threading.Timer(2.0, lambda: webbrowser.open('http://localhost:5000')).start()
        
        # Wait for user to stop
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n🛑 Shutting down EdgeGesture...")
        
        # Stop backend server
        if backend_process:
            backend_process.terminate()
            backend_process.wait()
            print("✅ Backend server stopped")
        
        print("👋 Goodbye!")

if __name__ == "__main__":
    main()
