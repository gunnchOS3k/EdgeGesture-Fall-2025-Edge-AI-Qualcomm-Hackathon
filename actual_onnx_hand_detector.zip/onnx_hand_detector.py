#!/usr/bin/env python3
"""
ONNX-based Hand Detector for improved performance
"""

import cv2
import numpy as np
import onnxruntime as ort
from typing import Tuple, Optional, List
import os

class ONNXHandDetector:
    def __init__(self, model_path: str = "models/hand_landmark.onnx"):
        """Initialize ONNX hand detector."""
        self.model_path = model_path
        self.session = None
        self.input_name = None
        self.output_names = None
        
        # Initialize ONNX runtime
        self._load_model()
        
        # Hand landmark indices
        self.landmark_indices = {
            'wrist': 0,
            'thumb_cmc': 1, 'thumb_mcp': 2, 'thumb_ip': 3, 'thumb_tip': 4,
            'index_mcp': 5, 'index_pip': 6, 'index_dip': 7, 'index_tip': 8,
            'middle_mcp': 9, 'middle_pip': 10, 'middle_dip': 11, 'middle_tip': 12,
            'ring_mcp': 13, 'ring_pip': 14, 'ring_dip': 15, 'ring_tip': 16,
            'pinky_mcp': 17, 'pinky_pip': 18, 'pinky_dip': 19, 'pinky_tip': 20
        }
        
    def _load_model(self):
        """Load ONNX model"""
        try:
            # Try to use GPU if available
            providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
            self.session = ort.InferenceSession(self.model_path, providers=providers)
            
            # Get input/output names
            self.input_name = self.session.get_inputs()[0].name
            self.output_names = [output.name for output in self.session.get_outputs()]
            
            print(f"ONNX model loaded successfully")
            print(f"   Input: {self.input_name}")
            print(f"   Outputs: {self.output_names}")
            
        except Exception as e:
            print(f"Failed to load ONNX model: {e}")
            print("Falling back to MediaPipe...")
            self._fallback_to_mediapipe()
    
    def _fallback_to_mediapipe(self):
        """Fallback to MediaPipe if ONNX fails"""
        try:
            import mediapipe as mp
            self.mp_hands = mp.solutions.hands
            self.hands = self.mp_hands.Hands(
                static_image_mode=False,
                max_num_hands=1,
                min_detection_confidence=0.5,
                min_tracking_confidence=0.3,
                model_complexity=0
            )
            self.mp_drawing = mp.solutions.drawing_utils
            self.use_mediapipe = True
            print("MediaPipe fallback initialized")
        except Exception as e:
            print(f"MediaPipe fallback failed: {e}")
            self.use_mediapipe = False
    
    def detect_hand(self, frame: np.ndarray) -> Tuple[Optional[Tuple[int, int]], bool, Optional[np.ndarray], Optional[Tuple[int, int]]]:
        """
        Detect hand in the frame and return finger positions and gesture info.
        
        Args:
            frame: Input BGR frame from webcam
            
        Returns:
            Tuple of:
            - index_finger_pos: (x, y) coordinates of index finger tip, or None if not detected
            - is_fist: Boolean indicating if hand is closed (fist gesture)
            - annotated_frame: Frame with hand landmarks drawn (for debugging)
            - thumb_pos: (x, y) coordinates of thumb tip, or None if not detected
        """
        if hasattr(self, 'use_mediapipe') and self.use_mediapipe:
            return self._detect_hand_mediapipe(frame)
        else:
            return self._detect_hand_onnx(frame)
    
    def _detect_hand_onnx(self, frame: np.ndarray) -> Tuple[Optional[Tuple[int, int]], bool, Optional[np.ndarray], Optional[Tuple[int, int]]]:
        """ONNX-based hand detection"""
        try:
            # Preprocess frame
            input_tensor = self._preprocess_frame(frame)
            
            # Run inference
            outputs = self.session.run(self.output_names, {self.input_name: input_tensor})
            
            # Postprocess results
            landmarks = self._postprocess_landmarks(outputs, frame.shape)
            
            if landmarks is not None:
                # Get frame dimensions
                h, w, _ = frame.shape
                
                # Get index finger tip
                index_tip = landmarks[self.landmark_indices['index_tip']]
                index_finger_pos = (int(index_tip[0] * w), int(index_tip[1] * h))
                
                # Get thumb tip
                thumb_tip = landmarks[self.landmark_indices['thumb_tip']]
                thumb_pos = (int(thumb_tip[0] * w), int(thumb_tip[1] * h))
                
                # Check if hand is closed
                is_fist = self._detect_fist_onnx(landmarks, w, h)
                
                # Create annotated frame
                annotated_frame = self._draw_landmarks(frame, landmarks)
                
                return index_finger_pos, is_fist, annotated_frame, thumb_pos
            else:
                return None, False, frame.copy(), None
                
        except Exception as e:
            print(f"ONNX detection error: {e}")
            return None, False, frame.copy(), None
    
    def _detect_hand_mediapipe(self, frame: np.ndarray) -> Tuple[Optional[Tuple[int, int]], bool, Optional[np.ndarray], Optional[Tuple[int, int]]]:
        """MediaPipe fallback detection"""
        # Convert BGR to RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process the frame
        results = self.hands.process(rgb_frame)
        
        index_finger_pos = None
        thumb_pos = None
        is_fist = False
        annotated_frame = frame.copy()
        
        if results.multi_hand_landmarks:
            # Get the first (and only) hand
            hand_landmarks = results.multi_hand_landmarks[0]
            
            # Draw hand landmarks on the frame
            self.mp_drawing.draw_landmarks(
                annotated_frame, 
                hand_landmarks, 
                self.mp_hands.HAND_CONNECTIONS
            )
            
            # Get frame dimensions
            h, w, _ = frame.shape
            
            # Get index finger tip (landmark 8)
            index_tip = hand_landmarks.landmark[8]
            index_finger_pos = (int(index_tip.x * w), int(index_tip.y * h))
            
            # Get thumb tip (landmark 4)
            thumb_tip = hand_landmarks.landmark[4]
            thumb_pos = (int(thumb_tip.x * w), int(thumb_tip.y * h))
            
            # Check if hand is closed (fist gesture)
            is_fist = self._detect_fist_mediapipe(hand_landmarks, w, h)
            
        return index_finger_pos, is_fist, annotated_frame, thumb_pos
    
    def _preprocess_frame(self, frame: np.ndarray) -> np.ndarray:
        """Preprocess frame for ONNX model"""
        # Resize to model input size (typically 224x224 for hand detection)
        input_size = 224
        resized = cv2.resize(frame, (input_size, input_size))
        
        # Convert BGR to RGB
        rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        
        # Normalize to [0, 1]
        normalized = rgb.astype(np.float32) / 255.0
        
        # Add batch dimension
        input_tensor = np.expand_dims(normalized, axis=0)
        
        return input_tensor
    
    def _postprocess_landmarks(self, outputs: List[np.ndarray], frame_shape: Tuple[int, int, int]) -> Optional[np.ndarray]:
        """Postprocess ONNX model outputs to get landmarks"""
        try:
            # This is a simplified version - actual implementation depends on the specific model
            # For now, we'll return None to trigger MediaPipe fallback
            return None
        except Exception as e:
            print(f"Postprocessing error: {e}")
            return None
    
    def _detect_fist_onnx(self, landmarks: np.ndarray, width: int, height: int) -> bool:
        """Detect fist using ONNX landmarks"""
        # Check if fingertips are close to their respective knuckles
        finger_tips = [4, 8, 12, 16, 20]  # Thumb, Index, Middle, Ring, Pinky tips
        finger_pips = [3, 6, 10, 14, 18]  # Corresponding PIP joints
        
        closed_fingers = 0
        
        for tip_idx, pip_idx in zip(finger_tips, finger_pips):
            tip_pos = landmarks[tip_idx]
            pip_pos = landmarks[pip_idx]
            
            # Calculate distance between tip and PIP
            distance = np.sqrt((tip_pos[0] - pip_pos[0])**2 + (tip_pos[1] - pip_pos[1])**2)
            
            # If distance is small, finger is likely closed
            if distance < 0.05:  # Threshold in normalized coordinates
                closed_fingers += 1
        
        # Consider it a fist if 4 or more fingers are closed
        return closed_fingers >= 4
    
    def _detect_fist_mediapipe(self, hand_landmarks, width: int, height: int) -> bool:
        """Detect fist using MediaPipe landmarks"""
        landmarks = hand_landmarks.landmark
        
        # Convert to pixel coordinates
        def to_pixel(landmark):
            return (int(landmark.x * width), int(landmark.y * height))
        
        # Check if fingertips are close to their respective knuckles
        finger_tips = [4, 8, 12, 16, 20]  # Thumb, Index, Middle, Ring, Pinky tips
        finger_pips = [3, 6, 10, 14, 18]  # Corresponding PIP joints
        
        closed_fingers = 0
        
        for tip_idx, pip_idx in zip(finger_tips, finger_pips):
            tip_pos = to_pixel(landmarks[tip_idx])
            pip_pos = to_pixel(landmarks[pip_idx])
            
            # Calculate distance between tip and PIP
            distance = np.sqrt((tip_pos[0] - pip_pos[0])**2 + (tip_pos[1] - pip_pos[1])**2)
            
            # If distance is small, finger is likely closed
            if distance < 30:  # Threshold in pixels
                closed_fingers += 1
        
        # Consider it a fist if 4 or more fingers are closed
        return closed_fingers >= 4
    
    def _draw_landmarks(self, frame: np.ndarray, landmarks: np.ndarray) -> np.ndarray:
        """Draw landmarks on frame"""
        annotated_frame = frame.copy()
        h, w, _ = frame.shape
        
        # Draw landmarks
        for landmark in landmarks:
            x = int(landmark[0] * w)
            y = int(landmark[1] * h)
            cv2.circle(annotated_frame, (x, y), 3, (0, 255, 0), -1)
        
        return annotated_frame
    
    def get_screen_region(self, x_pos: int, frame_width: int) -> str:
        """Determine which third of the screen the x position is in."""
        third = frame_width // 3
        
        if x_pos < third:
            return 'left'
        elif x_pos < 2 * third:
            return 'middle'
        else:
            return 'right'
