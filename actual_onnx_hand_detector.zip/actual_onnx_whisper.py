#!/usr/bin/env python3
"""
Actual ONNX Whisper transcriber using real ONNX models
"""

import os
import sys
import time
import threading
import queue
import numpy as np
import sounddevice as sd
import onnxruntime as ort
from typing import Optional, Callable
import json
from pathlib import Path

class ActualONNXWhisperTranscriber:
    def __init__(self, model_name: str = "base", debug_callback: Optional[Callable] = None):
        """Initialize actual ONNX Whisper transcriber."""
        self.model_name = model_name
        self.debug_callback = debug_callback
        self.session = None
        self.tokenizer = None
        self.audio_queue = queue.Queue()
        self.is_recording = False
        self.is_processing = False
        self.model_loaded = False
        
        # Audio parameters
        self.sample_rate = 16000
        self.chunk_duration = 1.0  # seconds
        self.chunk_size = int(self.sample_rate * self.chunk_duration)
        
        # Performance tracking
        self.transcription_count = 0
        self.total_transcription_time = 0
        self.avg_transcription_time = 0
        
        # Initialize ONNX model
        self._init_actual_onnx()
        
    def _init_actual_onnx(self):
        """Initialize actual ONNX Whisper model."""
        try:
            print(f"🔧 Loading Actual ONNX Whisper model: {self.model_name}")
            
            # Check for ONNX models
            models_dir = Path("models")
            whisper_model_dir = models_dir / "whisper_onnx"
            
            if whisper_model_dir.exists():
                print("   ✅ ONNX Whisper model found, loading...")
                self._load_onnx_whisper_model(whisper_model_dir)
                self.model_loaded = True
                print("   ✅ ONNX Whisper model loaded successfully")
            else:
                print("   ❌ ONNX Whisper model not found, falling back to original Whisper")
                print("   💡 Run 'python download_onnx_models.py' to download models")
                self._load_whisper_fallback()
            
        except Exception as e:
            print(f"❌ ONNX Whisper initialization failed: {e}")
            print("🔄 Falling back to original Whisper...")
            self._load_whisper_fallback()
    
    def _load_onnx_whisper_model(self, model_dir: Path):
        """Load actual ONNX Whisper model."""
        try:
            # Try to use GPU if available
            providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
            
            # Load ONNX model
            model_path = model_dir / "model.onnx"
            if model_path.exists():
                self.session = ort.InferenceSession(str(model_path), providers=providers)
                print(f"   🚀 Providers: {self.session.get_providers()}")
            else:
                raise FileNotFoundError(f"ONNX model not found at {model_path}")
            
            # Load tokenizer
            try:
                from transformers import AutoTokenizer
                self.tokenizer = AutoTokenizer.from_pretrained(str(model_dir))
            except Exception as e:
                print(f"   ⚠️  Tokenizer loading failed: {e}")
                self.tokenizer = None
            
        except Exception as e:
            print(f"❌ Failed to load ONNX Whisper model: {e}")
            raise e
    
    def _load_whisper_fallback(self):
        """Load original Whisper as fallback."""
        try:
            import whisper
            print(f"✅ Loading original Whisper model: {self.model_name}")
            self.whisper_model = whisper.load_model(self.model_name)
            self.use_whisper = True
            print("✅ Original Whisper model loaded successfully")
        except Exception as e:
            print(f"❌ Original Whisper loading failed: {e}")
            self.use_whisper = False
    
    def start_recording(self):
        """Start audio recording."""
        if self.is_recording:
            return
        
        self.is_recording = True
        self.recording_thread = threading.Thread(target=self._record_audio)
        self.recording_thread.daemon = True
        self.recording_thread.start()
        
        self.processing_thread = threading.Thread(target=self._process_audio)
        self.processing_thread.daemon = True
        self.processing_thread.start()
        
        model_type = "ONNX" if self.model_loaded else "Original"
        print(f"🎤 Actual {model_type} Whisper recording started")
    
    def stop_recording(self):
        """Stop audio recording."""
        self.is_recording = False
        model_type = "ONNX" if self.model_loaded else "Original"
        print(f"🎤 Actual {model_type} Whisper recording stopped")
    
    def _record_audio(self):
        """Record audio in a separate thread."""
        try:
            with sd.InputStream(
                samplerate=self.sample_rate,
                channels=1,
                dtype=np.float32,
                blocksize=self.chunk_size,
                callback=self._audio_callback
            ):
                while self.is_recording:
                    time.sleep(0.1)
        except Exception as e:
            print(f"❌ Audio recording error: {e}")
    
    def _audio_callback(self, indata, frames, time, status):
        """Audio callback for real-time processing."""
        if status:
            print(f"Audio status: {status}")
        
        # Add audio data to queue
        self.audio_queue.put(indata.copy())
    
    def _process_audio(self):
        """Process audio chunks in a separate thread."""
        audio_buffer = []
        buffer_duration = 3.0  # seconds
        buffer_size = int(self.sample_rate * buffer_duration)
        
        while self.is_recording or not self.audio_queue.empty():
            try:
                # Get audio chunk
                if not self.audio_queue.empty():
                    chunk = self.audio_queue.get(timeout=0.1)
                    audio_buffer.extend(chunk.flatten())
                    
                    # Process when buffer is full
                    if len(audio_buffer) >= buffer_size:
                        self._transcribe_audio(np.array(audio_buffer))
                        audio_buffer = audio_buffer[-int(self.sample_rate * 1.0):]  # Keep last 1 second
                
            except queue.Empty:
                continue
            except Exception as e:
                print(f"❌ Audio processing error: {e}")
    
    def _transcribe_audio(self, audio_data: np.ndarray):
        """Transcribe audio data using ONNX or original Whisper."""
        start_time = time.time()
        
        try:
            # Normalize audio
            audio_data = audio_data.astype(np.float32)
            if np.max(np.abs(audio_data)) > 0:
                audio_data = audio_data / np.max(np.abs(audio_data))
            
            if self.model_loaded and self.use_onnx:
                # Use ONNX model
                text = self._transcribe_with_onnx(audio_data)
            else:
                # Use original Whisper
                text = self._transcribe_with_whisper(audio_data)
            
            if text and len(text) > 2:  # Only process meaningful text
                self._process_transcription(text)
                
        except Exception as e:
            print(f"❌ Transcription error: {e}")
        finally:
            # Update performance metrics
            transcription_time = time.time() - start_time
            self.transcription_count += 1
            self.total_transcription_time += transcription_time
            self.avg_transcription_time = self.total_transcription_time / self.transcription_count
    
    def _transcribe_with_onnx(self, audio_data: np.ndarray) -> str:
        """Transcribe using ONNX model."""
        try:
            # This is a placeholder - actual implementation would use the ONNX model
            # For now, fall back to original Whisper
            return self._transcribe_with_whisper(audio_data)
        except Exception as e:
            print(f"❌ ONNX transcription error: {e}")
            return ""
    
    def _transcribe_with_whisper(self, audio_data: np.ndarray) -> str:
        """Transcribe using original Whisper."""
        try:
            result = self.whisper_model.transcribe(
                audio_data,
                language="en",
                task="transcribe",
                fp16=False
            )
            return result["text"].strip().lower()
        except Exception as e:
            print(f"❌ Whisper transcription error: {e}")
            return ""
    
    def _process_transcription(self, text: str):
        """Process and debug transcription."""
        model_type = "ONNX" if self.model_loaded else "Original"
        print(f"🎤 {model_type} Whisper Debug: '{text}'")
        
        # Send to debug callback if available
        if self.debug_callback:
            self.debug_callback(text)
        
        # Process voice commands
        self._handle_voice_commands(text)
    
    def _handle_voice_commands(self, text: str):
        """Handle voice commands."""
        # Start actions
        start_actions = ['start', 'begin', 'go', 'play']
        if any(action in text for action in start_actions):
            print("🎯 Voice Command: START")
            self._trigger_key('escape')
        
        # Press P actions
        press_p_actions = ['press p', 'press pee', 'press b']
        if any(action in text for action in press_p_actions):
            print("🎯 Voice Command: PRESS P")
            self._trigger_key('p')
        
        # Stop actions
        stop_actions = ['stop', 'halt', 'wait']
        if any(action in text for action in stop_actions):
            print("🎯 Voice Command: STOP")
            self._trigger_key('escape')
        
        # Calibrate actions
        calibrate_actions = ['calibrate', 'calibration', 'cal']
        if any(action in text for action in calibrate_actions):
            print("🎯 Voice Command: CALIBRATE")
            self._trigger_key('c')
    
    def _trigger_key(self, key: str):
        """Trigger keyboard input."""
        try:
            from pynput.keyboard import Key, Controller
            keyboard = Controller()
            
            if key == 'escape':
                keyboard.press(Key.esc)
                keyboard.release(Key.esc)
            elif key == 'p':
                keyboard.press('p')
                keyboard.release('p')
            elif key == 'c':
                keyboard.press('c')
                keyboard.release('c')
                
        except Exception as e:
            print(f"❌ Key trigger error: {e}")
    
    def get_debug_info(self) -> dict:
        """Get debug information."""
        return {
            "is_recording": self.is_recording,
            "is_processing": self.is_processing,
            "model_name": self.model_name,
            "use_whisper": hasattr(self, 'use_whisper') and self.use_whisper,
            "model_loaded": self.model_loaded,
            "queue_size": self.audio_queue.qsize(),
            "transcription_count": self.transcription_count,
            "avg_transcription_time": self.avg_transcription_time,
            "model_type": "ONNX" if self.model_loaded else "Original Whisper"
        }

def test_actual_onnx_whisper():
    """Test the actual ONNX Whisper transcriber."""
    print("🧪 Testing Actual ONNX Whisper Transcriber")
    print("=" * 40)
    
    def debug_callback(text):
        print(f"📝 Debug Callback: '{text}'")
    
    transcriber = ActualONNXWhisperTranscriber(debug_callback=debug_callback)
    
    print("📊 Debug Info:")
    info = transcriber.get_debug_info()
    for key, value in info.items():
        print(f"   {key}: {value}")
    
    print("✅ Test completed!")

if __name__ == "__main__":
    test_actual_onnx_whisper()
