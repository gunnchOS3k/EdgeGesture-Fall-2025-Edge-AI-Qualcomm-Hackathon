#!/usr/bin/env python3
"""
Backend Server for EdgeGesture Application
Bridges the React frontend with Python gesture and voice modules.
"""

import os
import sys
import subprocess
import threading
import time
import json
from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import webbrowser
from pathlib import Path

app = Flask(__name__)
CORS(app)

class EdgeGestureBackend:
    def __init__(self):
        self.whisper_process = None
        self.gesture_controller = None
        self.current_game = None
        self.is_running = False
        
        # Game configurations - mapping to actual Python scripts
        self.game_configs = {
            "Fruit Ninja": {
                "module": "control_mouse.py",
                "description": "Mouse control for slicing fruits with pinch gestures",
                "gestures": ["pinch", "move"],
                "voice_commands": ["start", "stop", "calibrate"]
            },
            "Pong": {
                "module": "pong.py", 
                "description": "Browser-based Pong game with hand gestures",
                "gestures": ["left", "right", "space"],
                "voice_commands": ["start", "stop"]
            },
            "Shooting": {
                "module": "shooting.py",
                "description": "FPS/Shooter game with gesture and voice controls", 
                "gestures": ["aim", "fire", "reload", "move"],
                "voice_commands": ["start", "fire", "reload", "stop"]
            }
        }
    
    def start_whisper(self):
        """Start the whisper voice recognition service"""
        try:
            whisper_path = os.path.join(os.path.dirname(__file__), "Whisper_functionality", "whisper_with_windows_automation.py")
            if os.path.exists(whisper_path):
                print(f"🎤 Starting Whisper from: {whisper_path}")
                self.whisper_process = subprocess.Popen([
                    sys.executable, whisper_path
                ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                print("✅ Whisper voice recognition started")
                return True
            else:
                print(f"❌ Whisper module not found at: {whisper_path}")
                return False
        except Exception as e:
            print(f"❌ Error starting whisper: {e}")
            return False
    
    def stop_whisper(self):
        """Stop the whisper voice recognition service"""
        if self.whisper_process:
            self.whisper_process.terminate()
            self.whisper_process = None
            print("🎤 Whisper voice recognition stopped")
    
    def start_game(self, game_name):
        """Start a specific game module"""
        try:
            if game_name in self.game_configs:
                module_path = os.path.join(os.path.dirname(__file__), self.game_configs[game_name]["module"])
                if os.path.exists(module_path):
                    # Stop current game if running
                    if self.gesture_controller:
                        self.stop_current_game()
                    
                    # Start new game
                    self.current_game = game_name
                    print(f"🎮 Starting {game_name} from: {module_path}")
                    self.gesture_controller = subprocess.Popen([
                        sys.executable, module_path
                    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    print(f"✅ Started {game_name}")
                    return True
                else:
                    print(f"❌ Game module not found: {module_path}")
                    return False
            else:
                print(f"❌ Unknown game: {game_name}")
                return False
        except Exception as e:
            print(f"❌ Error starting game: {e}")
            return False
    
    def stop_current_game(self):
        """Stop the currently running game"""
        if self.gesture_controller:
            self.gesture_controller.terminate()
            self.gesture_controller = None
            self.current_game = None
            print("🎮 Game stopped")
    
    def get_status(self):
        """Get current system status"""
        whisper_running = self.whisper_process is not None and self.whisper_process.poll() is None
        game_running = self.gesture_controller is not None and self.gesture_controller.poll() is None
        
        return {
            "whisper_running": whisper_running,
            "current_game": self.current_game,
            "game_running": game_running,
            "available_games": list(self.game_configs.keys())
        }

# Global backend instance
backend = EdgeGestureBackend()

@app.route('/')
def index():
    """Serve the main page"""
    return render_template('index.html')

@app.route('/api/status')
def get_status():
    """Get system status"""
    return jsonify(backend.get_status())

@app.route('/api/start-whisper', methods=['POST'])
def start_whisper():
    """Start whisper voice recognition"""
    success = backend.start_whisper()
    return jsonify({"success": success})

@app.route('/api/stop-whisper', methods=['POST'])
def stop_whisper():
    """Stop whisper voice recognition"""
    backend.stop_whisper()
    return jsonify({"success": True})

@app.route('/api/start-game', methods=['POST'])
def start_game():
    """Start a game"""
    data = request.get_json()
    game_name = data.get('game')
    if not game_name:
        return jsonify({"success": False, "error": "No game specified"})
    
    success = backend.start_game(game_name)
    return jsonify({"success": success})

@app.route('/api/stop-game', methods=['POST'])
def stop_game():
    """Stop current game"""
    backend.stop_current_game()
    return jsonify({"success": True})

@app.route('/api/games')
def get_games():
    """Get available games"""
    return jsonify(backend.game_configs)

@app.route('/api/gesture-detect', methods=['POST'])
def detect_gesture():
    """Detect gesture from image data (placeholder for future implementation)"""
    # This would integrate with the camera feed
    return jsonify({"gesture": "none", "confidence": 0.0})

def main():
    """Main function to start the backend server"""
    print("🚀 Starting EdgeGesture Backend Server")
    print("=" * 50)
    
    # Start whisper automatically
    print("🎤 Starting Whisper voice recognition...")
    backend.start_whisper()
    
    # Start Flask server
    print("🌐 Starting Flask server on http://localhost:5000")
    print("📱 Frontend will be available at http://localhost:5000")
    print("=" * 50)
    
    try:
        # Open browser automatically
        threading.Timer(2.0, lambda: webbrowser.open('http://localhost:5000')).start()
        
        # Start Flask app
        app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)
    except KeyboardInterrupt:
        print("\n🛑 Shutting down...")
        backend.stop_whisper()
        backend.stop_current_game()
        print("👋 Goodbye!")

if __name__ == "__main__":
    main()