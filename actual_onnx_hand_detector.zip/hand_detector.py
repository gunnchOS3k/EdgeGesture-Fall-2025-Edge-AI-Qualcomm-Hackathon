import mediapipe as mp
import cv2
import numpy as np

class HandDetector:
    def __init__(self):
        """Initialize the hand detector."""
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.5
        )
        self.mp_drawing = mp.solutions.drawing_utils
    
    def process(self, image):
        """Process an image to detect hands."""
        return self.hands.process(image)
    
    def draw_landmarks(self, image, hand_landmarks):
        """Draw hand landmarks on the image."""
        self.mp_drawing.draw_landmarks(
            image, hand_landmarks, self.mp_hands.HAND_CONNECTIONS)