#!/usr/bin/env python3
"""
EdgeGesture Web Application
Integrated web interface for voice and gesture control
"""

import os
import sys
import subprocess
import threading
import time
import webbrowser
import json
import cv2
import mediapipe as mp
import numpy as np
import math
from flask import Flask, render_template, jsonify, request, Response
from flask_cors import CORS
from onnx_whisper_transcriber import ONNXWhisperTranscriber
from proper_gesture_detector import ProperGestureDetector

app = Flask(__name__)
CORS(app)

class GestureDetector:
    """Gesture detection using MediaPipe - integrated from your code"""
    def __init__(self):
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.5
        )
        self.mp_drawing = mp.solutions.drawing_utils
        self.mp_drawing_styles = mp.solutions.drawing_styles
        self.gesture_history = []
        self.history_size = 5
    
    def calculate_distance(self, point1, point2):
        return math.sqrt((point1.x - point2.x)**2 + (point1.y - point2.y)**2)
    
    def is_finger_extended(self, landmarks, finger_tip_idx, finger_pip_idx, finger_mcp_idx, hand_side):
        tip = landmarks[finger_tip_idx]
        pip = landmarks[finger_pip_idx]
        mcp = landmarks[finger_mcp_idx]
        
        if finger_tip_idx == 4:  # Thumb
            if hand_side == "left":
                return tip.x > mcp.x and tip.x > pip.x
            else:
                return tip.x < mcp.x and tip.x < pip.x
        else:
            return tip.y < pip.y
    
    def get_finger_states(self, landmarks, hand_side):
        finger_states = {}
        finger_states['thumb'] = self.is_finger_extended(landmarks, 4, 3, 2, hand_side)
        finger_states['index'] = self.is_finger_extended(landmarks, 8, 6, 5, hand_side)
        finger_states['middle'] = self.is_finger_extended(landmarks, 12, 10, 9, hand_side)
        finger_states['ring'] = self.is_finger_extended(landmarks, 16, 14, 13, hand_side)
        finger_states['pinky'] = self.is_finger_extended(landmarks, 20, 18, 17, hand_side)
        return finger_states
    
    def detect_gesture(self, landmarks, hand_side):
        if not landmarks:
            return "none", 0.0
        
        finger_states = self.get_finger_states(landmarks, hand_side)
        extended_count = sum(finger_states.values())
        
        thumb_extended = finger_states['thumb']
        index_extended = finger_states['index']
        middle_extended = finger_states['middle']
        ring_extended = finger_states['ring']
        pinky_extended = finger_states['pinky']
        
        thumb_tip = landmarks[4]
        index_tip = landmarks[8]
        thumb_index_dist = self.calculate_distance(thumb_tip, index_tip)
        
        # Gesture detection logic from your code
        if extended_count == 0:
            return "fist", 0.9
        elif (thumb_extended and not index_extended and not middle_extended and 
              not ring_extended and not pinky_extended and thumb_index_dist > 0.1):
            return "thumbs_up", 0.9
        elif (not thumb_extended and index_extended and middle_extended and 
              not ring_extended and not pinky_extended):
            return "peace", 0.9
        elif (thumb_extended and index_extended and not middle_extended and 
              not ring_extended and not pinky_extended and 0.05 < thumb_index_dist < 0.15):
            return "ok", 0.9
        elif (not thumb_extended and index_extended and not middle_extended and 
              not ring_extended and not pinky_extended):
            return "point", 0.9
        elif extended_count == 1:
            return "thumbs_up" if thumb_extended else "one_finger", 0.8
        elif extended_count == 2:
            if index_extended and middle_extended:
                return "peace", 0.8
            elif thumb_extended and index_extended:
                return "ok", 0.8
            else:
                return "two_fingers", 0.8
        elif extended_count == 3:
            return "three_fingers", 0.8
        elif extended_count == 4:
            return "four_fingers", 0.9 if not pinky_extended else 0.7
        elif extended_count == 5:
            return "open_hand", 0.9
        
        return "none", 0.0
    
    def process_frame(self, frame):
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.hands.process(rgb_frame)
        
        detected_gestures = []
        
        if results.multi_hand_landmarks:
            h, w = frame.shape[:2]
            
            for idx, hand_landmarks in enumerate(results.multi_hand_landmarks):
                # Draw hand landmarks
                self.mp_drawing.draw_landmarks(
                    frame, hand_landmarks, self.mp_hands.HAND_CONNECTIONS,
                    self.mp_drawing_styles.get_default_hand_landmarks_style(),
                    self.mp_drawing_styles.get_default_hand_connections_style()
                )
                
                # Determine hand side
                if results.multi_handedness:
                    hand_side = results.multi_handedness[idx].classification[0].label.lower()
                else:
                    hand_center_x = hand_landmarks.landmark[9].x
                    hand_side = "left" if hand_center_x < 0.5 else "right"
                
                # Detect gesture
                gesture, confidence = self.detect_gesture(hand_landmarks.landmark, hand_side)
                
                # Store gesture data
                hand_data = {
                    'side': hand_side,
                    'gesture': gesture,
                    'confidence': confidence,
                    'center': (int(hand_landmarks.landmark[9].x * w), int(hand_landmarks.landmark[9].y * h))
                }
                
                detected_gestures.append(hand_data)
                
                # Draw gesture info on frame
                center = hand_data['center']
                color = (0, 255, 0) if hand_side == "left" else (0, 0, 255)
                cv2.circle(frame, center, 12, color, -1)
                cv2.circle(frame, center, 15, color, 2)
                
                # Draw gesture text
                text = f"{hand_side.upper()}: {gesture.upper()}"
                text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]
                text_x = center[0] - text_size[0] // 2
                text_y = center[1] - 25
                
                cv2.rectangle(frame, 
                            (text_x - 5, text_y - text_size[1] - 5), 
                            (text_x + text_size[0] + 5, text_y + 5), 
                            (0, 0, 0), -1)
                
                cv2.putText(frame, text, 
                           (text_x, text_y), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)
        
        # Update gesture history
        self.gesture_history.append(detected_gestures)
        if len(self.gesture_history) > self.history_size:
            self.gesture_history.pop(0)
        
        return frame, detected_gestures

class EdgeGestureWebApp:
    def __init__(self):
        self.whisper_process = None
        self.gesture_controller = None
        self.current_game = None
        self.whisper_transcriber = None
        self.whisper_debug_log = []
        self.max_debug_entries = 50
        
        # Gesture detection
        self.gesture_detector = ProperGestureDetector()
        self.current_gestures = []
        self.gesture_mapping_mode = False
        self.pending_gesture_mapping = None
        
        # Camera for gesture detection
        self.camera_active = False
        self.cap = None
                # Game configurations
        self.game_configs = {
            "Fruit Ninja": {
                "module": "control_mouse.py",
                "description": "Mouse control for slicing fruits with pinch gestures",
                "gestures": ["pinch", "move"]
            },
            "Pong": {
                "module": "pong.py", 
                "description": "Browser-based Pong game with hand gestures",
                "gestures": ["left", "right", "space"]
            },
            "Racing": {
                "module": "racing_controller.py",
                "description": "Steering wheel racing game with hand grip detection",
                "gestures": ["grip", "open", "steer"]
            }
        }
    
    def start_whisper(self):
        """Start ONNX whisper voice recognition with debugging"""
        try:
            print(f"🎤 Starting ONNX Whisper with debugger...")
            
            # Create debug callback
            def debug_callback(text):
                timestamp = time.strftime("%H:%M:%S")
                debug_entry = {
                    "timestamp": timestamp,
                    "text": text,
                    "type": "transcription"
                }
                self.whisper_debug_log.append(debug_entry)
                
                # Keep only recent entries
                if len(self.whisper_debug_log) > self.max_debug_entries:
                    self.whisper_debug_log = self.whisper_debug_log[-self.max_debug_entries:]
                
                print(f"🎤 Whisper Debug [{timestamp}]: '{text}'")
            
            # Initialize ONNX Whisper transcriber
            self.whisper_transcriber = ONNXWhisperTranscriber(
                model_name="base",
                debug_callback=debug_callback
            )
            
            # Start recording
            self.whisper_transcriber.start_recording()
            
            return True
            
        except Exception as e:
            print(f"❌ Error starting ONNX Whisper: {e}")
            # Fallback to original Whisper
            return self._start_original_whisper()
    
    def _start_original_whisper(self):
        """Fallback to original Whisper implementation"""
        try:
            whisper_path = os.path.join(os.path.dirname(__file__), "Whisper_functionality", "whisper_with_windows_automation.py")
            if os.path.exists(whisper_path):
                print(f"🎤 Starting original Whisper...")
                self.whisper_process = subprocess.Popen([
                    sys.executable, whisper_path
                ])
                return True
            else:
                print(f"❌ Whisper not found at: {whisper_path}")
                return False
        except Exception as e:
            print(f"❌ Error starting original whisper: {e}")
            return False
    
    def stop_whisper(self):
        """Stop whisper voice recognition"""
        if self.whisper_transcriber:
            self.whisper_transcriber.stop_recording()
            self.whisper_transcriber = None
            print("🎤 ONNX Whisper stopped")
        elif self.whisper_process:
            self.whisper_process.terminate()
            self.whisper_process = None
            print("🎤 Original Whisper stopped")
    
    
    def start_gesture_mapping(self, gesture_type, gesture_value):
        """Start gesture mapping mode"""
        self.gesture_mapping_mode = True
        self.pending_gesture_mapping = {
            'gesture_type': gesture_type,
            'gesture_value': gesture_value
        }
        print(f"🎯 Gesture mapping mode started for {gesture_type}: {gesture_value}")
    
    def stop_gesture_mapping(self):
        """Stop gesture mapping mode"""
        self.gesture_mapping_mode = False
        self.pending_gesture_mapping = None
        print("🎯 Gesture mapping mode stopped")
    
    def start_camera(self):
        """Start camera for gesture detection - clean backend approach"""
        try:
            # Release any existing camera
            if self.cap is not None:
                self.cap.release()
            
            # Initialize camera (same as working examples)
            self.cap = cv2.VideoCapture(0)
            if not self.cap.isOpened():
                print("❌ Error: Could not open camera")
                return False
            
            # Set camera properties for better performance
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self.cap.set(cv2.CAP_PROP_FPS, 30)
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            
            # Give camera a moment to initialize
            import time
            time.sleep(0.1)
            
            # Test camera with a frame read
            ret, frame = self.cap.read()
            if not ret:
                print("❌ Error: Could not read from camera")
                self.cap.release()
                return False
            
            self.camera_active = True
            print("✅ Backend camera started successfully")
            return True
            
        except Exception as e:
            print(f"❌ Error starting camera: {e}")
            if self.cap:
                self.cap.release()
                self.cap = None
            return False
    
    def stop_camera(self):
        """Stop camera"""
        self.camera_active = False
        if self.cap:
            self.cap.release()
            self.cap = None
        print("📹 Camera stopped")
    
    # Camera frames are read directly in the stream endpoint
    
    

    def start_game(self, game_name):
        """Start a game module"""
        try:
            if game_name in self.game_configs:
                # Stop current game
                if self.gesture_controller:
                    self.stop_game()
                
                # Start new game
                self.current_game = game_name
                print(f"🎮 Starting {game_name}...")
                
                # Special handling for Racing game
                if game_name == "Racing":
                    # Import and run the racing controller directly
                    from racing_controller import RobustSimpleRacingController
                    controller = RobustSimpleRacingController()
                    # Run in a separate thread to avoid blocking
                    racing_thread = threading.Thread(target=controller.run, daemon=True)
                    racing_thread.start()
                    print(f"✅ {game_name} started successfully")
                    return True
                else:
                    # Start other games in a subprocess
                    module_path = os.path.join(os.path.dirname(__file__), self.game_configs[game_name]["module"])
                    if os.path.exists(module_path):
                        self.gesture_controller = subprocess.Popen([
                            sys.executable, module_path
                        ])
                        return True
                    else:
                        print(f"❌ Game module not found: {module_path}")
                        return False
            else:
                print(f"❌ Unknown game: {game_name}")
                return False
        except Exception as e:
            print(f"❌ Error starting game: {e}")
            return False
    
    def stop_game(self):
        """Stop current game"""
        if self.gesture_controller:
            self.gesture_controller.terminate()
            self.gesture_controller = None
            self.current_game = None
            print("🎮 Game stopped")
    
    def get_status(self):
        """Get system status"""
        whisper_running = False
        if self.whisper_transcriber:
            whisper_running = self.whisper_transcriber.is_recording
        elif self.whisper_process:
            whisper_running = self.whisper_process.poll() is None
        
        game_running = self.gesture_controller is not None and self.gesture_controller.poll() is None
        
        return {
            "whisper_running": whisper_running,
            "current_game": self.current_game,
            "game_running": game_running,
            "available_games": list(self.game_configs.keys()),
            "whisper_debug_log": self.whisper_debug_log[-10:]  # Last 10 entries
        }

# Global app instance
web_app = EdgeGestureWebApp()

@app.route('/')
def index():
    """Serve the main page"""
    return render_template('index.html')


@app.route('/api/status')
def get_status():
    """Get system status"""
    return jsonify(web_app.get_status())

@app.route('/api/start-whisper', methods=['POST'])
def start_whisper():
    """Start whisper voice recognition"""
    success = web_app.start_whisper()
    return jsonify({"success": success})

@app.route('/api/stop-whisper', methods=['POST'])
def stop_whisper():
    """Stop whisper voice recognition"""
    web_app.stop_whisper()
    return jsonify({"success": True})

@app.route('/api/start-game', methods=['POST'])
def start_game():
    """Start a game"""
    data = request.get_json()
    game_name = data.get('game')
    if not game_name:
        return jsonify({"success": False, "error": "No game specified"})
    
    success = web_app.start_game(game_name)
    return jsonify({"success": success})

@app.route('/api/stop-game', methods=['POST'])
def stop_game():
    """Stop current game"""
    web_app.stop_game()
    return jsonify({"success": True})

@app.route('/api/games')
def get_games():
    """Get available games"""
    return jsonify(web_app.game_configs)

@app.route('/api/whisper-debug')
def get_whisper_debug():
    """Get Whisper debug log"""
    return jsonify({
        "debug_log": web_app.whisper_debug_log,
        "whisper_info": web_app.whisper_transcriber.get_debug_info() if web_app.whisper_transcriber else None
    })


@app.route('/api/start-gesture-mapping', methods=['POST'])
def start_gesture_mapping():
    """Start gesture mapping mode"""
    data = request.get_json()
    gesture_type = data.get('gesture_type')
    gesture_value = data.get('gesture_value')
    
    if not gesture_type or not gesture_value:
        return jsonify({"success": False, "error": "Missing gesture_type or gesture_value"})
    
    web_app.start_gesture_mapping(gesture_type, gesture_value)
    return jsonify({"success": True})

@app.route('/api/stop-gesture-mapping', methods=['POST'])
def stop_gesture_mapping():
    """Stop gesture mapping mode"""
    web_app.stop_gesture_mapping()
    return jsonify({"success": True})

@app.route('/start_camera', methods=['POST'])
def start_camera():
    """Start camera - EXACT copy from working demo"""
    success = web_app.start_camera()
    return {'success': success}

@app.route('/stop_camera', methods=['POST'])
def stop_camera():
    """Stop camera - EXACT copy from working demo"""
    web_app.stop_camera()
    return {'success': True}

@app.route('/api/detected-gestures')
def get_detected_gestures():
    """Get currently detected gestures for live detection"""
    if not web_app.camera_active or not web_app.cap:
        return jsonify({"gestures": []})
    
    # Get the latest detected gestures from the gesture detector
    gestures = getattr(web_app.gesture_detector, 'last_detected_gestures', [])
    print(f"🎯 API called - detected {len(gestures)} gestures: {[g['gesture'] for g in gestures]}")
    return jsonify({"gestures": gestures})

@app.route('/video_feed')
def video_feed():
    """Stream camera feed with gesture detection - EXACT copy from working demo"""
    print("🎥 Video feed endpoint called")
    print(f"Camera active: {web_app.camera_active}")
    print(f"Camera cap: {web_app.cap is not None}")
    
    # Auto-start camera if not already active (like working test code)
    if not web_app.camera_active or web_app.cap is None:
        print("🎥 Auto-starting camera for video feed")
        web_app.start_camera()
    
    def generate_frames():
        frame_count = 0
        while web_app.camera_active and web_app.cap is not None:
            ret, frame = web_app.cap.read()
            if not ret:
                print("❌ Failed to read frame from camera")
                break
            
            frame_count += 1
            if frame_count % 30 == 0:  # Print every 30 frames
                print(f"🎥 Streaming frame {frame_count}")
            
            # Flip frame horizontally for mirror effect
            frame = cv2.flip(frame, 1)
            
            # Process frame for gesture detection
            processed_frame, gestures = web_app.gesture_detector.process_frame(frame)
            
            # Draw status
            cv2.putText(processed_frame, f"Gestures: {len(gestures)}", 
                       (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            
            # Encode frame as JPEG
            ret, buffer = cv2.imencode('.jpg', processed_frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
            if ret:
                frame_bytes = buffer.tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
            else:
                print("❌ Failed to encode frame")
                break
    
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/api/process-frame', methods=['POST'])
def process_frame():
    """Process frame from frontend camera for gesture detection"""
    try:
        if 'frame' not in request.files:
            return jsonify({"error": "No frame provided"}), 400
        
        frame_file = request.files['frame']
        if frame_file.filename == '':
            return jsonify({"error": "No frame selected"}), 400
        
        # Read frame data
        frame_data = frame_file.read()
        nparr = np.frombuffer(frame_data, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if frame is None:
            return jsonify({"error": "Could not decode frame"}), 400
        
        # Process frame for gesture detection using proper gesture detector
        processed_frame, gestures = web_app.gesture_detector.process_frame(frame)
        
        # Convert gestures to the format expected by frontend
        formatted_gestures = []
        for gesture in gestures:
            formatted_gestures.append({
                'side': gesture['side'],
                'gesture': gesture['gesture'],
                'confidence': gesture['confidence'],
                'center': gesture['center']
            })
        
        return jsonify({
            "success": True,
            "gestures": formatted_gestures
        })
        
    except Exception as e:
        print(f"❌ Error processing frame: {e}")
        return jsonify({"error": str(e)}), 500


def main():
    """Main function"""
    print("🚀 Starting EdgeGesture Web Application")
    print("=" * 50)
    
    # Start whisper automatically
    print("🎤 Starting Whisper voice recognition...")
    web_app.start_whisper()
    
    print("🌐 Starting web server on http://localhost:5000")
    print("📱 Open your browser to http://localhost:5000")
    print("=" * 50)
    
    try:
        # Open browser
        threading.Timer(2.0, lambda: webbrowser.open('http://localhost:5000')).start()
        
        # Start Flask app
        app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)
    except KeyboardInterrupt:
        print("\n🛑 Shutting down...")
        web_app.stop_whisper()
        web_app.stop_game()
        print("👋 Goodbye!")

if __name__ == "__main__":
    main()
