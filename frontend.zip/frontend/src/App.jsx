import React, { useEffect, useMemo, useRef, useState } from "react";

/**
 * EdgeGesture – Main Menu & Gesture Mapper (single-file React UI)
 * -----------------------------------------------------------------
 * What this does
 * - Home screen with three game tiles (Fruit Ninja, Pong, Racing)
 * - High‑polish UI styling (Tailwind classes) with lightweight SVG logos
 * - "Open Gesture Mapper" lets users see camera preview and assign gestures / voice
 * - Per‑game default mappings are loaded; users can override + persist to localStorage
 * - Camera preview uses getUserMedia; recording/recognition UI is stubbed for hackathon demo
 *
 * How to run (fastest):
 *   1) Create a Vite React app (or use CRA). In Vite: npm create vite@latest edge-gesture -- --template react
 *   2) Install Tailwind (optional for best look) or keep as-is – it still works with plain CSS fallback.
 *   3) Replace App.jsx with this file's contents and run `npm run dev`.
 *
 * Notes
 * - This is a front-end prototype. Plug in your actual gesture/voice backends later.
 * - We persist mappings in localStorage key: "edgeGesture.mappings.v1".
 */

// ---------- helpers ----------------------------------------------------------
const GAMES = ["Fruit Ninja", "Pong", "Racing"];

const DEFAULTS = {
  "Fruit Ninja": [
    {
      id: cryptoRandomId(),
      action: "Slice",
      gestureType: "HandPose",
      value: "Pinch (index + thumb)",
      notes: "Hold pinch to arm the blade; move hand to slice."
    },
    {
      id: cryptoRandomId(),
      action: "Start Game",
      gestureType: "Voice",
      value: "start",
      notes: "Say \"start\" from main menu."
    },
    {
      id: cryptoRandomId(),
      action: "Pause / Resume",
      gestureType: "HandPose",
      value: "OpenPalm (hold)",
      notes: "Hold open palm steady for 0.8s to toggle pause."
    }
  ],
  Pong: [
    {
      id: cryptoRandomId(),
      action: "Paddle Move (P1 – left side only)",
      gestureType: "HandMotion",
      value: "OpenPalm (vertical track)",
      notes: "Use LEFT hand only."
    },
    {
      id: cryptoRandomId(),
      action: "Paddle Move (P2 – right side only)",
      gestureType: "HandMotion",
      value: "OpenPalm (vertical track)",
      notes: "Use RIGHT hand only."
    },
    {
      id: cryptoRandomId(),
      action: "Start Game",
      gestureType: "Voice",
      value: "start",
      notes: "Say \"start\" to begin."
    }
  ],
  Racing: [
    {
      id: cryptoRandomId(),
      action: "Steer",
      gestureType: "HandMotion",
      value: "TwoHands (wheel tilt)",
      notes: "Both hands visible; rotate like a steering wheel."
    },
    {
      id: cryptoRandomId(),
      action: "Drive Forward",
      gestureType: "HandPose",
      value: "TwoFists",
      notes: "Make two fists to accelerate forward."
    },
    {
      id: cryptoRandomId(),
      action: "Brake / Reverse",
      gestureType: "HandPose",
      value: "TwoOpenPalms",
      notes: "Two open hands = brake; hold to reverse."
    },
    {
      id: cryptoRandomId(),
      action: "Full Stop",
      gestureType: "HandPose",
      value: "3&9 Palms",
      notes: "Palms open at 3 and 9 o'clock = stop vehicle."
    },
    {
      id: cryptoRandomId(),
      action: "Start Race",
      gestureType: "Voice",
      value: "start",
      notes: "Say \"start\" on the grid."
    }
  ]
};

function cryptoRandomId() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return Math.random().toString(36).slice(2);
}

// ---------- storage ---------------------------------------------------------
const STORAGE_KEY = "edgeGesture.mappings.v1";
function loadMappings() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return structuredClone(DEFAULTS);
    const parsed = JSON.parse(raw);
    // basic shape guard
    const result = {};
    for (const g of GAMES) {
      result[g] = Array.isArray(parsed[g]) && parsed[g].length ? parsed[g] : DEFAULTS[g];
    }
    return result;
  } catch {
    return structuredClone(DEFAULTS);
  }
}
function saveMappings(m) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(m));
}

// ---------- SVG app logos ---------------------------------------------------
const LogoFruit = () => (
  <svg viewBox="0 0 64 64" className="w-12 h-12 drop-shadow"><defs><linearGradient id="g1" x1="0" x2="1"><stop offset="0%" stopColor="#34d399"/><stop offset="100%" stopColor="#10b981"/></linearGradient></defs>
    <circle cx="32" cy="32" r="20" fill="url(#g1)" />
    <path d="M22 28c6 6 14 6 20 0" stroke="#065f46" strokeWidth="3" fill="none" strokeLinecap="round"/>
    <path d="M30 16c2-6 8-8 11-5-3 2-6 4-7 9" stroke="#047857" strokeWidth="2" fill="none"/>
  </svg>
);
const LogoPong = () => (
  <svg viewBox="0 0 64 64" className="w-12 h-12 drop-shadow">
    <rect x="10" y="14" width="6" height="36" rx="3" fill="#60a5fa"/>
    <rect x="48" y="14" width="6" height="36" rx="3" fill="#60a5fa"/>
    <circle cx="32" cy="32" r="4" fill="#93c5fd" />
  </svg>
);
const LogoRacing = () => (
  <svg viewBox="0 0 64 64" className="w-12 h-12 drop-shadow">
    <circle cx="20" cy="44" r="8" fill="#9ca3af"/>
    <circle cx="44" cy="44" r="8" fill="#9ca3af"/>
    <rect x="14" y="26" width="36" height="10" rx="5" fill="#111827"/>
    <rect x="18" y="22" width="22" height="6" rx="3" fill="#374151"/>
  </svg>
);

// ---------- UI components ---------------------------------------------------
function App() {
  const [view, setView] = useState("menu");
  const [selectedGame, setSelectedGame] = useState(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-800 text-zinc-100">
      <header className="max-w-6xl mx-auto px-6 pt-8 pb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="inline-flex items-center justify-center w-10 h-10 rounded-2xl bg-emerald-500/90 shadow-lg">
            {/* brand spark */}
            <svg viewBox="0 0 32 32" className="w-6 h-6"><path d="M16 2l3 8 8 3-8 3-3 8-3-8-8-3 8-3z" fill="black"/></svg>
          </span>
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">EdgeGesture</h1>
            <p className="text-sm text-zinc-400">Voice + Hand UI • Snapdragon / Windows</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setView("mapper")}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-medium shadow-lg"
          >Gesture Mapper</button>
          <button
            onClick={() => setView("menu")}
            className="px-4 py-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 text-zinc-100 border border-zinc-700"
          >Main Menu</button>
        </div>
      </header>

      {view === "menu" ? (
        <MainMenu onOpen={(g) => { setSelectedGame(g); setView("mapper"); }} />
      ) : (
        <MapperScreen initialGame={selectedGame ?? "Fruit Ninja"} />
      )}

      <footer className="max-w-6xl mx-auto px-6 py-6 text-xs text-zinc-500">
        Demo UI only. Plug in Whisper / Vosk for voice and MediaPipe / OpenCV for hands. Mappings persist locally.
      </footer>
    </div>
  );
}

function MainMenu({ onOpen }) {
  const cards = [
    { name: "Fruit Ninja", logo: <LogoFruit />, blurb: "Pinch to slice • Voice: start" },
    { name: "Pong", logo: <LogoPong />, blurb: "Open palm paddle • Left/Right hands" },
    { name: "Racing", logo: <LogoRacing />, blurb: "Two fists drive • Two palms brake" }
  ];

  return (
    <div className="max-w-6xl mx-auto px-6 pb-14">
      <section className="mt-4">
        <h2 className="text-lg text-zinc-300 mb-3">Games</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {cards.map((c) => (
            <button key={c.name}
              onClick={() => onOpen(c.name)}
              className="group relative overflow-hidden rounded-3xl bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700 hover:border-emerald-400/60 shadow-xl">
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-emerald-500/10"/>
              <div className="p-6 flex items-center gap-4">
                {c.logo}
                <div className="text-left">
                  <div className="text-xl font-semibold tracking-tight">{c.name}</div>
                  <div className="text-sm text-zinc-400">{c.blurb}</div>
                </div>
              </div>
              <div className="px-6 pb-6 pt-2 text-right text-xs text-zinc-500">Tap to configure controls →</div>
            </button>
          ))}
        </div>
      </section>

      <section className="mt-10">
        <h2 className="text-lg text-zinc-300 mb-3">Quick Voice</h2>
        <div className="rounded-2xl bg-zinc-900/60 border border-zinc-700 p-5 text-sm text-zinc-300">
          Say <span className="text-emerald-400">"start"</span> to begin a selected game. Implement via Whisper/Vosk.
        </div>
      </section>
    </div>
  );
}

function MapperScreen({ initialGame }) {
  const [activeGame, setActiveGame] = useState(initialGame);
  const [mappings, setMappings] = useState(loadMappings());
  const current = mappings[activeGame];

  useEffect(() => { saveMappings(mappings); }, [mappings]);

  return (
    <div className="max-w-6xl mx-auto px-6 pb-20">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-3">
          <h2 className="text-xl font-semibold">Gesture Mapper</h2>
          <GameTabs active={activeGame} onChange={setActiveGame} />
        </div>
        <div className="flex gap-2">
          <button className="px-3 py-1.5 rounded-lg bg-zinc-800 border border-zinc-700 text-sm hover:bg-zinc-700"
            onClick={() => { const fresh = structuredClone(DEFAULTS); setMappings(fresh); }}>
            Reset to Defaults
          </button>
          <button className="px-3 py-1.5 rounded-lg bg-zinc-800 border border-zinc-700 text-sm hover:bg-zinc-700"
            onClick={() => { navigator.clipboard.writeText(JSON.stringify(mappings, null, 2)); }}>
            Copy JSON
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <MappingTable
            rows={current}
            onChange={(rows) => setMappings({ ...mappings, [activeGame]: rows })}
          />
        </div>
        <div className="lg:col-span-1">
          <CameraPanel />
          <VoicePanel />
        </div>
      </div>
    </div>
  );
}

function GameTabs({ active, onChange }) {
  return (
    <div className="flex gap-1 rounded-xl bg-zinc-800/60 border border-zinc-700 p-1">
      {GAMES.map((g) => (
        <button key={g} onClick={() => onChange(g)}
          className={`px-3 py-1.5 rounded-lg text-sm ${active === g ? "bg-emerald-500 text-black" : "text-zinc-300 hover:text-white"}`}>{g}</button>
      ))}
    </div>
  );
}

const HAND_POSES = [
  "Pinch (index+thumb)",
  "OpenPalm",
  "Fist",
  "TwoOpenPalms",
  "TwoFists",
  "3&9 Palms"
];
const HAND_MOTIONS = [
  "OpenPalm (vertical track)",
  "SwipeLeft",
  "SwipeRight",
  "SwipeUp",
  "SwipeDown",
  "TwoHands (wheel tilt)"
];

function MappingTable({ rows, onChange }) {
  function update(id, patch) {
    onChange(rows.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }
  function addRow() {
    onChange([
      ...rows,
      { id: cryptoRandomId(), action: "New Action", gestureType: "HandPose", value: HAND_POSES[0] }
    ]);
  }
  function removeRow(id) {
    onChange(rows.filter((r) => r.id !== id));
  }

  return (
    <div className="rounded-2xl border border-zinc-700 bg-zinc-900/50 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-700">
        <div className="text-sm text-zinc-300">Action → Gesture bindings</div>
        <button onClick={addRow} className="px-3 py-1.5 rounded-lg bg-emerald-500 text-black text-sm">Add binding</button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-zinc-900/70">
            <tr className="text-left text-zinc-400">
              <th className="px-4 py-2">Action</th>
              <th className="px-4 py-2">Type</th>
              <th className="px-4 py-2">Gesture / Voice</th>
              <th className="px-4 py-2">Notes</th>
              <th className="px-2 py-2 w-10" />
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-zinc-800">
                <td className="px-4 py-2">
                  <input className="w-full bg-transparent border border-zinc-700 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-emerald-400"
                    value={r.action}
                    onChange={(e) => update(r.id, { action: e.target.value })}
                  />
                </td>
                <td className="px-4 py-2">
                  <select value={r.gestureType}
                    onChange={(e) => update(r.id, { gestureType: e.target.value, value: "" })}
                    className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-2 py-1">
                    <option value="HandPose">Hand Pose</option>
                    <option value="HandMotion">Hand Motion</option>
                    <option value="Voice">Voice</option>
                  </select>
                </td>
                <td className="px-4 py-2">
                  {r.gestureType === "Voice" ? (
                    <VoiceCapture value={r.value} onChange={(v) => update(r.id, { value: v })} />
                  ) : (
                    <select value={r.value}
                      onChange={(e) => update(r.id, { value: e.target.value })}
                      className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-2 py-1">
                      {(r.gestureType === "HandPose" ? HAND_POSES : HAND_MOTIONS).map((g) => (
                        <option key={g} value={g}>{g}</option>
                      ))}
                    </select>
                  )}
                </td>
                <td className="px-4 py-2">
                  <input className="w-full bg-transparent border border-zinc-700 rounded-lg px-2 py-1"
                    placeholder="Optional notes"
                    value={r.notes ?? ""}
                    onChange={(e) => update(r.id, { notes: e.target.value })}
                  />
                </td>
                <td className="px-2 py-2 text-right">
                  <button onClick={() => removeRow(r.id)} className="px-2 py-1 rounded-md bg-zinc-800 border border-zinc-700 hover:bg-zinc-700">✕</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CameraPanel() {
  const videoRef = useRef(null);
  const [on, setOn] = useState(false);
  const [error, setError] = useState(null);
  const streamRef = useRef(null);

  useEffect(() => {
    return () => {
      // cleanup on unmount
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  async function startCam() {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 360 } });
      streamRef.current = s;
      setError(null);
      setOn(true);
      if (videoRef.current) videoRef.current.srcObject = s;
    } catch (e) {
      setError(e?.message ?? "Camera error");
      setOn(false);
    }
  }
  function stopCam() {
    if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setOn(false);
  }

  return (
    <div className="rounded-2xl border border-zinc-700 bg-zinc-900/50 overflow-hidden mb-4">
      <div className="px-4 py-3 border-b border-zinc-700 text-sm text-zinc-300">Camera Preview</div>
      <div className="p-4 space-y-3">
        <video ref={videoRef} autoPlay playsInline muted className="w-full rounded-xl bg-black aspect-video object-cover" />
        {error && <div className="text-xs text-red-400">{error}</div>}
        <div className="flex gap-2">
          {!on ? (
            <button onClick={startCam} className="px-3 py-1.5 rounded-lg bg-emerald-500 text-black text-sm">Start camera</button>
          ) : (
            <button onClick={stopCam} className="px-3 py-1.5 rounded-lg bg-zinc-800 border border-zinc-700 text-sm">Stop</button>
          )}
          <div className="text-xs text-zinc-400 self-center">Use this to visually debug your hand poses / motion.</div>
        </div>
      </div>
    </div>
  );
}

function VoicePanel() {
  return (
    <div className="rounded-2xl border border-zinc-700 bg-zinc-900/50 overflow-hidden">
      <div className="px-4 py-3 border-b border-zinc-700 text-sm text-zinc-300">Voice Commands</div>
      <div className="p-4 text-sm text-zinc-300 space-y-2">
        <p>Integrate Whisper (OpenAI) or Vosk to recognize short commands like <span className="text-emerald-400">"start"</span>, <span className="text-emerald-400">"shoot"</span>, <span className="text-emerald-400">"dump"</span>, <span className="text-emerald-400">"cease"</span>.</p>
        <p className="text-xs text-zinc-400">Tip: run voice on-device for offline demo parity.</p>
      </div>
    </div>
  );
}

function VoiceCapture({ value, onChange }) {
  const [recording, setRecording] = useState(false);
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);

  // This is a UI stub – wire to your recognizer later
  function fakeRecord() {
    setRecording(true);
    setTimeout(() => {
      setRecording(false);
      if (!text) setText("start");
      onChange(text || "start");
    }, 900);
  }

  return (
    <div className="flex items-center gap-2">
      <input
        className="flex-1 bg-transparent border border-zinc-700 rounded-lg px-2 py-1"
        placeholder="e.g., start / shoot / dump / cease"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onBlur={() => onChange(text)}
      />
      <button onClick={fakeRecord}
        className={`px-2.5 py-1.5 rounded-lg text-sm ${recording ? "bg-red-500 text-black" : "bg-zinc-800 border border-zinc-700"}`}>{recording ? "Recording…" : "Record"}</button>
    </div>
  );
}

export default App;
