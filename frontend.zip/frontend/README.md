# EdgeGesture Frontend

A React-based frontend for the EdgeGesture AI-powered hand gesture controller system.

## Features

- **Game Selection**: Choose from Fruit Ninja, Pong, and Racing games
- **Gesture Mapping**: Configure hand poses, motions, and voice commands for each game
- **Camera Preview**: Real-time camera feed for testing gestures
- **Voice Commands**: UI for voice command configuration (stubbed for demo)
- **Persistent Storage**: Mappings are saved to localStorage
- **Modern UI**: Built with Tailwind CSS for a polished look

## Quick Start

### Prerequisites
- Node.js 16+ 
- npm or yarn

### Installation

1. **Navigate to the frontend directory:**
   ```bash
   cd /Users/deeptanshu./Desktop/Edge_AI/frontend
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Start the development server:**
   ```bash
   npm run dev
   ```

4. **Open your browser:**
   Navigate to `http://localhost:3000`

## Project Structure

```
frontend/
├── src/
│   ├── App.jsx          # Main application component
│   └── main.jsx         # React entry point
├── index.html           # HTML template
├── package.json         # Dependencies and scripts
├── vite.config.js       # Vite configuration
└── README.md           # This file
```

## Usage

### Main Menu
- **Game Tiles**: Click on Fruit Ninja, Pong, or Racing to configure controls
- **Quick Voice**: Information about voice command integration

### Gesture Mapper
- **Game Tabs**: Switch between different games
- **Action Mappings**: Configure gesture-to-action bindings
- **Camera Preview**: Test your gestures in real-time
- **Voice Commands**: Set up voice recognition (stubbed)

### Gesture Types
- **Hand Pose**: Static hand positions (Pinch, Open Palm, Fist, etc.)
- **Hand Motion**: Dynamic movements (Swipes, tracking, etc.)
- **Voice**: Spoken commands

### Default Mappings

#### Fruit Ninja
- **Slice**: Pinch (index + thumb) - Hold pinch to arm blade, move to slice
- **Start Game**: Voice command "start"
- **Pause/Resume**: Open Palm (hold for 0.8s)

#### Pong
- **Paddle Move (P1)**: Open Palm (vertical track) - Left hand only
- **Paddle Move (P2)**: Open Palm (vertical track) - Right hand only  
- **Start Game**: Voice command "start"

#### Racing
- **Steer**: Two Hands (wheel tilt) - Rotate like steering wheel
- **Drive Forward**: Two Fists - Accelerate forward
- **Brake/Reverse**: Two Open Palms - Brake and reverse
- **Full Stop**: 3&9 Palms - Stop vehicle
- **Start Race**: Voice command "start"

## Integration Notes

This is a **frontend prototype** that demonstrates the UI/UX for EdgeGesture. To make it fully functional:

1. **Backend Integration**: Connect to your Python gesture recognition backend
2. **Voice Recognition**: Integrate Whisper, Vosk, or similar for voice commands
3. **Real-time Gesture Detection**: Connect to MediaPipe/HuggingFace models
4. **Game Integration**: Connect to actual game engines

## Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

### Technologies Used

- **React 18** - UI framework
- **Vite** - Build tool and dev server
- **Tailwind CSS** - Styling (via CDN)
- **TypeScript** - Type safety (via JSDoc comments)

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Future Enhancements

- Real-time gesture visualization overlay
- Gesture training mode
- Performance metrics display
- Multi-language support
- Accessibility improvements
- PWA capabilities

## License

Part of the EdgeGesture project - built for Copilot+ PC and Snapdragon X/X Elite platforms.
